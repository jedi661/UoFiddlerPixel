﻿# Dragon Map Studio

Nachbau und Erweiterung von **Dragon 1.03.62 (IMod13)** als UoFiddler-Werkzeug.
Geöffnet wird es im Plugin *ConverterMultiText* → Reiter **Map** → Knopf **Dragon Map Studio** (unter *Uo Map*).

Dragon bestand aus drei Programmen und vielen Skripten:

| Dragon | Dragon Map Studio |
|---|---|
| `Dragon.exe` (BMP → map.mul + Statics als WSC) | Reiter **MUL / UOP erzeugen** (map#.mul, staidx#.mul, statics#.mul, map#LegacyMUL.uop, WSC) |
| `Dragonsp.exe` (Statics in statics.mul einspielen) | Option **Statics übernehmen** (alte staidx/statics mischen) |
| `Dragon_m2b.exe` (map.mul → BMP) | **MUL / UOP → BMP** (auch UOP) |
| Skripte (`groups`, `maptrans`, `betweentrans*`, `statbetweentrans*`, `items`, `unevenly`, Fix-Tabelle) | alle als Tabellen im Reiter **Regeln & Skripte**, Export zurück ins Dragon-Format |
| Photoshop-Farbtabelle / Paletten (`Addon`) | Reiter **Farbtabelle**, Import/Export ACT, PAL, ACO, GPL |

Neu dazu: Karten-Editor mit Undo/Redo, Zufalls-Generator, Umriss-Import aus Bildern, Kartenliste,
eigenes JSON-Format mit allen Informationen, Prüfbericht für fehlende Übergänge.

---

## 1. Reiter

### Farbtabelle
- Zeigt `IMod13_Colortable.bmp`. Jeder Pixel kennt seinen Palettenindex (= **Farbadresse**).
- **Linksklick** kopiert die Adresse in die Zwischenablage. Format oben wählbar:
  `0a`, `0x0A`, `10`, `#RRGGBB`, `r,g,b`, komplette maptrans-Zeile oder alles.
- **Rechtsklick** = Malfarbe 1, **mittlere Maustaste** = Malfarbe 2 im Editor.
- Rechts: 16×16-Palette, Infos (Gruppe, Höhe, Tiles, Tile-Bild aus dem Client) und alle Werte zum Bearbeiten.
- **Neue Farbe definieren** legt auf dem ersten freien Index eine eigene Farbe an
  (Name, Kategorie, Gruppe, Höhe, Tiles, Textur-Bild).
- **Aus Regeln erzeugen** zeichnet eine aktuelle Farbtabelle (auch mit eigenen Farben).

### Karten-Editor
Werkzeuge: Pinsel (B), Radierer (E), Sprühen, Linie (L), Rechteck, Rechteck gefüllt (R), Ellipse,
Ellipse gefüllt, Füllen (F), Pipette (I), Höhe + / Höhe −, Auswahl (S), Hand (H).

- Linke Maus = Farbe 1, rechte Maus = Farbe 2.
- Mausrad = Zoom, mittlere Maus / Leertaste / Pfeiltasten = verschieben, `[` `]` = Pinselgröße.
- Strg+Z / Strg+Y, Auswahl: Strg+C / Strg+X / Strg+V (Stempel), Entf, Strg+F, Strg+A.
- **Höhe + / −** wählt die nächste Farbe derselben Gruppe (die IMod-Farben kodieren die Höhe).
- Kartenliste des Projekt-Ordners: Öffnen, Neu, Duplizieren, Umbenennen, Löschen (Papierkorb).
- Übersicht unten links (klicken = hinspringen). 8×8-Raster = UO-Blöcke.
- Undo/Redo speichert nur geänderte 64×64-Kacheln – auch 7168×4096 bleibt flüssig.

### CGI-Ansicht (neu)
Die gebaute Karte so ansehen, wie sie im Client aussieht, Fehler finden und Statics bearbeiten.

- **Aus Editor-Karte bauen** – baut im Speicher (Übergänge, Items, Unebenheit …) und zeigt das Ergebnis.
  Im Karten-Editor springt **CGI-Ansicht hier** an dieselbe Stelle.
- **MUL / UOP laden** – fertige Karte (`map#.mul` / `map#LegacyMUL.uop` + `staidx#`/`statics#` aus dem Ordner).
- Darstellung: 44×44-Land-Kacheln, Texturen (texmaps) an Hängen mit Licht, Statics mit Hue, Client-Reihenfolge,
  Raster, Max Z (unter Dächer schauen). Ohne Client-Dateien: Dragon-Farben als Ersatz.
- Rechte Leiste: Übersicht (Klick = springen, orange = Auswahl aus dem Karten-Editor), *Gehe zu X/Y*,
  Item-Liste mit Suche (Name / hex), Hue mit Farbfeld, Z-Versatz, *auf Statics stapeln*, Multis mit Vorschau,
  Eigenschaften der Auswahl (ID, Hue, Z, X, Y), Fehlersuche.
- Werkzeuge: Auswahl, Static setzen, Multi setzen, Löschen, Färben. Rechtsklick = ID + Hue übernehmen.

| Taste | Wirkung |
|---|---|
| Pfeile | Auswahl 1 Tile verschieben (↑ Norden y−1, → Osten x+1); ohne Auswahl: Ansicht |
| Strg + Pfeil | Kopie der Auswahl daneben einfügen, Kopie wird ausgewählt (mehrmals = Mauer/Zaun ziehen) |
| Bild↑ / Bild↓ | Z ±1 (Umschalt ±5) |
| Entf / H / Esc | löschen / mit Hue färben / Auswahl aufheben |
| Strg+C, Strg+V | kopieren, einfügen (Linksklick setzt, mehrfach) |
| Strg+A | alle Statics unter der Maus |
| Strg+Z, Strg+Y | Rückgängig, Wiederholen |

- **Probleme**: Land/Statics ohne Grafik, Steilkanten (ab einstellbarer Höhe), Statics im Boden, doppelte Statics.
- **Speichern**: Statics; bei einer im Speicher gebauten Karte auch `map#.mul` (und UOP, wenn in den Build-Optionen an).
  Vorhandene Dateien werden vorher als `.bak` gesichert.

### Generator & Umriss
- **Generator**: Seed, Land-%, Kontinent-Größe, Küsten-Rauheit, Wasserrand, Strand, Gebirge, Schnee,
  Klima (Norden kalt), Höhen. Die Höhe wird über die Farbe der Gruppe gesetzt.
- **Biome ohne Übergang trennen**: zwischen zwei Gruppen ohne Übergangsregel wird automatisch eine
  „Brücken-Gruppe“ gesetzt (z. B. Wald zwischen Gras und GrassBump). Test 2048×2048: Rand-Tiles ohne
  Übergang von 19 497 auf 515.
- **Biome**: Tabelle Temperatur/Feuchte → Gruppe (Reihenfolge = Priorität).
- **Umriss-Bild**: PNG mit Transparenz oder dunkle Silhouette auf hellem Grund.
  - *In Karte zeichnen*: Land + Wasser, nur Land, nur Küstenlinie oder alles.
  - *Als Maske für Generator*: Land nur innerhalb des Umrisses, mit natürlicher Küste.
  - *Maske aus aktueller Karte*: deine gemalte Land/Wasser-Verteilung wird zur Maske.
- Presets speichern / laden (JSON).

### Regeln & Skripte
Gruppen, Farben (maptrans), Übergänge (mit 3×3-Mustervorschau), Items mit Objekt-Gruppen,
Unebenheit, Fix-Tabelle, Farb-Aliase, Hinweise. Gruppen, Indizes und Tiles werden hex angezeigt.
Neue Zeilen unten in einer Tabelle = neue Regel / neues Muster. Eine neue Übergangs- oder Item-Datei
entsteht automatisch, sobald eine Regel mit neuem Dateinamen ausgewählt wird.

### MUL / UOP erzeugen
Ablauf wie Dragon: Farbe → Gruppe/Höhe/Tile, Unebenheit, Map-Übergänge (8 Nachbarn), Static-Übergänge,
Items, Fix-Tabelle, optional alte Statics übernehmen. Ausgabe: `map#.mul`, `staidx#.mul`, `statics#.mul`,
optional `map#LegacyMUL.uop` (über den UOP-Packer von UoFiddler) und `statics#.wsc`.
`build_report.txt` listet Rand-Tiles ohne Übergang:
- **Muster fehlt** → in der Übergangsdatei ergänzen,
- **Regel fehlt** → für die zwei Gruppen eine Übergangsdatei anlegen.

### Einstellungen
Projekt-Ordner (Karten), Ausgabe-Ordner (MUL/UOP), Skript-Ordner, Farbtabelle, Palette, Regelsatz-JSON,
maptrans-Datei, Kopier-Format, Raster, Undo-Speicher, Größe neuer Karten.
Gespeichert in `<UoFiddler AppData>\DragonMapStudio\settings.json`.

---

## 2. Dragon-Format – was das Studio daraus gelesen hat

| Datei | Format | Bedeutung |
|---|---|---|
| `groups.txt` | `II GG` | Palettenindex → Gruppe; Kommentar `// GG = Name` = Gruppenname |
| `maptrans.txt` | `II ZZZ T1 T2 …` | Index, Höhe (dezimal), Land-Tiles (hex, zufällig) |
| `betweentrans.txt` | `AA BB datei` | Zelle Gruppe A neben Gruppe B → `map/datei` |
| `betweentrans2.txt` | `AA datei` | Gruppe A neben *jeder* anderen → `map2/` |
| `statbetweentrans.txt` | `AA BB datei` | wie oben, setzt Statics → `statics/` |
| `statbetweentrans2/3.txt` | `GG datei` | 2: Zelle G neben anderen → `statics2/`, 3: andere neben G → `statics3/` |
| Übergangsdatei | `MUSTER T1 … Z1 Z2` | 8 Zeichen A/B im Uhrzeigersinn ab Nordwest: NW N NO O SO S SW W |
| `items.txt` | `GG Chance L T R B datei` | Chance pro Zelle (Basis 1000), Rechteck, `items/datei` |
| Item-Datei | `Häufigkeit (id z hue dx dy)…` | mehrteilige Objekte, Gewichtung nach Häufigkeit |
| `unevenly.txt` | `GG Freq L T R B Höhe` | zufällige Höhe 0..Höhe für Freq/1000 der Zellen |
| Fix-Tabelle | `X Y ID Z` | setzt einzelne Tiles zum Schluss (`fixtable.fix` im Skript-Ordner) |

Auskommentierte Regeln (`//03 11 roof.txt`) bleiben als **deaktiviert** erhalten.
Beim Laden gefundene Fehler der IMod13-Skripte: `statics/cave2blackRalls.txt` (Tippfehler) und
`statics/grass2wasteland.txt` fehlen; Farben `1e` und `7e` haben keine Gruppe.

**Noch zu prüfen im Spiel:** Bedeutung der zwei Zahlen hinter den Tiles (Z1/Z2). Umgesetzt ist:
Map-Übergang Z1 = Höhe +Z1 (abschaltbar), Static Z = Bodenhöhe + Z1; Z2 wird gespeichert, aber nicht benutzt.
Mehrere IDs in einer Static-Zeile: alle setzen (Standard) oder eine zufällig (Einstellung).

---

## 3. Eigenes Format (JSON)

*Regeln → Regelsatz (JSON) speichern* schreibt **alles** in eine Datei: 256 Farben (RGB, Name, Kategorie,
Gruppe, Höhe, Tiles, Textur, Kommentar), Gruppen, alle Übergangsregeln und -muster, Items, Unebenheit,
Fix-Tabelle, Farb-Aliase und die Kopfkommentare der Dragon-Dateien.
Ist in den Einstellungen ein Regelsatz eingetragen, wird er statt der Skripte geladen.
*Als Dragon-Skripte exportieren* schreibt wieder den kompletten Skript-Ordner (Rundreise geprüft:
gleiche Farben, 154 Regeln, 4 341 Muster, 1 069 Item-Gruppen).

Erweitern: neue Eigenschaft in `Core/DragonModel.cs` anlegen – sie erscheint automatisch in Tabellen,
Eigenschaftsfenstern und im JSON.

---

## 4. Dateien

```
DragonMapStudio/
├─ DragonMapStudioForm.cs / .Designer.cs / .resx   Hauptfenster (VS-Designer)
├─ DragonMapStudioForm.Tools.cs                    Generator, Umriss, Regeln, Build, Einstellungen
├─ DragonMapStudioForm.Cgi.cs                      CGI-Ansicht (Client-Ansicht, Statics bearbeiten)
├─ DragonMapStudioForm.Fix.cs                      Prüfen / Reparieren, Logs, Hilfe-Sprache
├─ Controls/
│  ├─ ColorTableView.cs     klickbare Farbtabelle
│  ├─ PaletteGridView.cs    16×16-Palette
│  ├─ MapCanvas.cs          Zeichenfläche mit allen Werkzeugen
│  ├─ MapNavigator.cs       Übersicht
│  └─ IsoMapView.cs         CGI-Ansicht: isometrisch zeichnen, Statics bearbeiten
├─ Dialogs/NewMapDialog.*   Neue Karte (VS-Designer)
├─ Core/
│  ├─ DragonModel.cs        Datenklassen (Farbe, Gruppe, Übergang, Item …)
│  ├─ DragonRuleSet.cs      kompletter Regelsatz + JSON
│  ├─ DragonScriptIO.cs     Dragon-Skripte lesen / schreiben
│  ├─ PaletteIO.cs          ACT, PAL (JASC/RIFF), ACO, GPL, BMP-Palette
│  ├─ IndexedMap.cs         8-Bit-Karte + Undo/Redo (MapHistory)
│  ├─ IndexedBitmapIO.cs    8-Bit-BMP lesen/schreiben, RGB-Bilder umrechnen
│  ├─ MapGenerator.cs       Perlin-Rauschen, Biome, Strand, Brücken-Gruppen
│  ├─ OutlineImporter.cs    Umriss aus Bild → Maske / Karte
│  ├─ DragonCompiler.cs     BMP → MUL (der eigentliche Dragon-Ablauf)
│  ├─ MulMapIO.cs           MUL/UOP lesen/schreiben, MUL → BMP
│  ├─ MapData.cs            gebaute Karte: Land + Statics (bearbeitbar, Undo/Redo)
│  ├─ UoArtCache.cs         Client-Grafiken (Art, Texturen, Hues, Multis, Radarfarben)
│  ├─ MapProblemScanner.cs  Fehlersuche (CGI)
│  ├─ MapFixer.cs           Prüfen / Reparieren nach Tutorial-Regeln + zweisprachige Logs
│  ├─ ColorTableRenderer.cs Farbtabelle aus den Regeln zeichnen
│  ├─ StudioSettings.cs     Einstellungen + Pfade
│  └─ StudioHelp.cs         Hilfetext
└─ DragonData/              Original IMod13: Scripts/ und Addon/ (wird nach plugins\DragonMapStudio\ kopiert)
```

Geändert: `UserControls/ConverterMultiTextControl(.Designer).cs` (Knopf), `Properties/Resources(.resx/.Designer.cs)`
+ `Resources/dragon-map-studio.png` (Symbol), `.csproj` (DragonData kopieren).

## 5. Getestet

- Kompiliert ohne Fehler und Warnungen (C# / .NET 8, wie das Plugin).
- Skripte laden: 249 Farben, 31 Gruppen, 154 Übergänge, 96 Übergangsdateien, 4 341 Muster, 23 Item-Dateien.
- Rundreise Skripte → JSON → Skripte verlustfrei.
- 8-Bit-BMP schreiben/lesen bytegenau. MUL-Größen stimmen (Blöcke × 196, StaIdx 12 Byte/Block, Statics 7 Byte).
- UOP schreiben und wieder lesen: identisch.
- 2048×2048: Generator ≈ 4 s, Build ≈ 3 s. Oberfläche unter Wine gestartet, alle Reiter, Generator,
  Umriss, Undo/Redo, Build.
- **Nicht getestet:** echtes Windows, die erzeugten Dateien im UO-Client.

---

## 6. Ausbau-Plan (zum gemeinsamen Planen)

1. **Im Client prüfen** – Z1/Z2 der Übergänge, Item-Chance, Static-Höhen festlegen.
2. **Übergangs-Editor**: Muster per Klick im 3×3-Raster, Tiles per Drag & Drop aus der UoFiddler-Kachelliste,
   fehlende Muster aus `build_report.txt` mit einem Klick anlegen.
3. ~~Echte Vorschau~~ → erledigt (CGI-Ansicht). Weiter: Land in der CGI-Ansicht bearbeiten (Höhe, Tile), Auswahl per Rahmen ziehen, Statics mit der Maus ziehen.
4. **UOP komplett**: Statics in UOP-Clients, UOP-Karte direkt öffnen/speichern, Client-Ordner direkt beschreiben (mit Backup).
5. **Mehr Generator**: Flüsse, Seen, Straßen, Städte/Dungeon-Bereiche, Höhenkarte als Graustufen-Import/-Export, Erosion.
6. **Ebenen**: getrennte Ebenen für Terrain, Höhe, Statics-Zonen; Höhe frei malen statt über die Farbe.
7. **Mehr als 256 Farben**: eigenes 16-Bit-Kartenformat (Dragon-BMP bleibt als Export).
8. **Bereichsregeln**: Items/Unebenheit per gemaltem Bereich statt Rechteck.
9. **Statics-Import**: vorhandene Statics anzeigen und als Schicht bearbeiten.

---

## Prüfen, Reparieren und Logs (Version 3)

Grundlage: *UO Dragon Mod 11 – Map Making Tutorial* (Ryandor, 2002).

### Was aus dem Tutorial übernommen wurde

| Tutorial | Umsetzung |
|---|---|
| Übergangs-Zeile `AAAABBBB 0238 005 007`: neue Höhe = alte Höhe + Zufall 5..7 | Build: Höhe + Zufall zwischen Z1 und Z2 (vorher nur + Z1) |
| Statics: „höchste Höhe der umliegenden Tiles der Quellgruppe + Z“ | Option *Static-Z von den Nachbarn* (Standard an) |
| „itemid1 to x will be used randomly“ | Statics: eine ID zufällig (Standard *RandomOne*, vorher alle IDs → doppelte Statics) |
| Übergänge brauchen mindestens 2 Tiles nebeneinander | Reparatur entfernt Einzel-Tiles und 1 Tile breite Streifen |
| Sumpf immer mit mindestens 2 Tiles Gras umgeben | Umgebungs-Regel `18:00:2` |
| Berge in Ringen: Rock 20, 30, 50, 60, 65, 70, nicht über 80 | Berg-Profil `20 30 50 60 65 70 80 90` |
| Höhen in Stufen 5, 10, 15 … | Höhensprünge begrenzen (Land 10, Berg 20) |
| GrassBump immer tiefer als angrenzendes Gras | Prüfung `19:00` (Hinweis im Log) |
| Remove Statics (sonst doppelte Items) | *Doppelte Statics entfernen* beim Build und in der CGI-Ansicht |

### Knöpfe

- **Bearbeiten → Karte prüfen (Log)** oder Reiter *MUL / UOP erzeugen* → **Karte prüfen (Log)**:
  ändert nichts, schreibt `map_check_log.txt` in den Ausgabe-Ordner.
- **Karte reparieren**: repariert die Editor-Karte (ein Rückgängig-Schritt), schreibt `map_fix_log.txt`.
- **Vor dem Build reparieren** (Build-Optionen → *5 Reparatur*): repariert nur eine Kopie beim Build.
- **Log öffnen**: zeigt das zuletzt geschriebene Log.
- Build schreibt `dragon_log.txt`; die CGI-Ansicht hat *Doppelte entfernen* und *Log speichern* (`cgi_check_log.txt`).

Alle Logs sind **Deutsch + Englisch** und enthalten **Koordinaten** (bis 15 Beispiele je Fehlerart) –
zum Weiterschicken an mich, damit wir gezielt Regeln / Übergänge ergänzen können.

Test 2048×2048 (generiert, ohne Reparatur → mit Reparatur): Rand-Tiles ohne Übergang 19 497 → 64,
Steilkanten (≥ 30 z) 10 → 0, doppelte Statics werden entfernt.

### CGI-Ansicht: Küsten-Darstellung

Land-Kacheln ohne Textur (z. B. Wasser) wurden an Hängen falsch verzerrt – daher die schwarzen Dreiecke an der
Küste. Jetzt wird die Kachel über zwei Dreiecke exakt auf die vier Ecken gelegt; sehr steile, entartete Kacheln
werden einfarbig gefüllt statt die ganze Ansicht abbrechen zu lassen.

---

## English summary

Dragon Map Studio rebuilds Dragon 1.03.62 (IMod13) inside UoFiddler: paint the map as 8-bit image, check and
repair it, build `map#.mul`, `staidx#.mul`, `statics#.mul` (+ `map#LegacyMUL.uop`), look at the result in the
**CGI view** (client like) and edit statics / multis there.

- **Check / repair** follows the Dragon tutorial: no single tiles or 1 tile strips, swamp surrounded by 2 tiles of
  grass, bridge groups between groups without transition, mountains rising in rings (20 30 50 60 65 70),
  limited height jumps, GrassBump lower than grass.
- **Build**: transition height = old height + random Z1..Z2, static z = highest z of the source group neighbours
  + Z, one random static id per line, duplicates removed.
- **Logs** (`dragon_log.txt`, `map_check_log.txt`, `map_fix_log.txt`, `cgi_check_log.txt`) are German + English with
  coordinates – send them for analysis.
- Help tab: language selection German / English.

---

## Version 4: Küsten, Berge, Höhlen, Land bearbeiten

| Problem (deine Bilder) | Ursache | Lösung |
|---|---|---|
| Zacken / „Zelte“ an der Küste | Daten: `sand2water`, `grass2water` setzen Kanten-Tiles auf −10, Ecken bleiben 0 → Zickzack. Zusätzlich hat die Ansicht nasse Kacheln ohne Textur gestreckt. | Build-Option **Küste glätten** (Durchschnitt der Ufer-Höhen); die Ansicht zeichnet nasse Kacheln ohne Textur flach wie der Client. Test 2048²: 0 Sprünge ≥ 8 zwischen Ufer-Nachbarn. |
| Ufer-Welle zu hoch | Static-Z = höchste Wasserhöhe + 10; `water2x` senkt das Ufer-Wasser auf −15…−5 | **Static-Z Basis = SourceLowest** (tiefstes Wasser + 10 ≈ Wasserhöhe). Ø z der Wellen jetzt −7,7. |
| Berg tiefer als Gras („Mulde“) | Berg-Profil 20/30/50… war absolut, Gras lag schon auf 25–30 | Berg-Profil jetzt **relativ zum Boden**: Ring n liegt zwischen Boden + h/2 und Boden + h. Generator ebenso. Test: 0 Berg-Tiles tiefer als das Land daneben. |
| Keine Höhlen | `map/cave-enti2mountain.txt` liegt bei, ist aber nicht in `betweentrans.txt` | Generator setzt Höhleneingänge (Gruppe 1d) am Bergrand und aktiviert die Regel 1d → Berg. Die Reparatur lässt Gruppe 1d in Ruhe. Nicht eingetragene Übergangsdateien werden jetzt mitgeladen. |

**CGI-Ansicht – Land bearbeiten** (zweite Leiste „Land“, Reiter „Land“ mit Land-Grafik und Textur):
Land setzen, Höhe +, Höhe −, Höhe =, Glätten (Radius, Schritt), Rechtsklick nimmt Land-ID + Höhe auf.
**Bereich**: Strg+C / Strg+V (Land + Statics, Höhe passt sich an), Entf (Statics löschen), Bild↑/↓ (heben/senken).
**Höhen** blendet die Z-Werte ein – auch im Karten-Editor ab Zoom 12.

Einstellungen werden beim ersten Start auf Version 4 umgestellt (StaticZ = SourceLowest, Küste glätten an,
Gebirgshöhen 15–70 über Boden). / Settings are migrated to version 4 on first start.

---

## Version 5: Küste wie das Original, Höhen-Analyse, Größen-Erkennung

**Dein CGI-Log:** Alle 2 051 „Steilkanten“ lagen genau an 8er-Blockgrenzen (x mod 8 = 7). Ursache: Eine
2048×2048-MUL hat keine Standardgröße, die CGI-Ansicht hat beim Laden 7168×4096 angenommen und die Blöcke an
falsche Stellen gelegt. **Behoben:** Die Größe kommt jetzt aus Dateigröße + offener Editor-Karte (quadratisch,
übliche Höhen; auch für UOP). Die Steilkanten in diesem Log und vermutlich auch die 2 949 „im Boden“ sind dadurch nicht echt.

**Küste (Build-Optionen „6 Küste“, Standard an):**

| | vorher | jetzt (wie Original-Bilder) |
|---|---|---|
| Wasser am Ufer | −5 / −15 zufällig, 1 Tile breit | gleichmäßig −15, 6 Tiles breit |
| Land am Wasser | −10 oder 0 (Zickzack) | −5, dann −2, dann 0 (Abstand 1, 2, 3) |
| Ufer-Statics (Wellen) | Wasserhöhe + 10 | fest z 0 |

Klippen-Küsten (Land > 10) bleiben. Alle Werte sind einstellbar.

**„Karte analysieren (Höhen-Log)“** (CGI-Ansicht → Probleme): lädt man die **Original-map0.mul**, schreibt das
Werkzeug `map_analysis_log.txt` mit: Land-Höhe nach Abstand zum Wasser, Wasser-Höhe nach Abstand zum Land,
häufigste Ufer-Tiles, Statics an der Küste (z absolut und über Land), Höhensprünge, Land-Tiles mit Höhen.
Mit markiertem Bereich zusätzlich ein Raster (Höhe, Land-ID, Statics). **Diese Datei aus dem Original bitte
schicken** – dann stelle ich Küsten-Profil, Wellen-Höhe und Berg-Regeln genau auf die Originalwerte ein.

Außerdem: Höhleneingänge (1d) erscheinen nicht mehr als „Regel fehlt“ im Log (die offene Seite ist gewollt).

---

## Version 6: Küste nach der Original-map0

Ausgewertet mit „Karte analysieren“ auf der Original-`map0.mul` (7168×4096, 2,79 Mio. Statics):

| Original map0 | Bedeutung | Umsetzung (Build-Optionen „6 Küste“) |
|---|---|---|
| Land-Tile `0064` 564 000×, 88 % auf z −15, in 1–6 Tiles Abstand zum offenen Wasser | Ufer-Wasser ist **Meeresgrund**, kein Wasser-Tile | Wasser in 1–6 Tiles Abstand zum Land → Tile `0064`, z −15 (äußerer Ring −5) |
| Statics `1797`–`179c` je ~100 000×, z −5, 10 über dem Land | **Wasser-Statics** liegen auf dem Grund | auf jedes dieser Tiles ein zufälliges `1797`–`179c` auf z −5 (nicht dort, wo schon ein Ufer-Static liegt) |
| `1796`, `17a9`, `17ab`, `179f`, `17a0` … abs z −5 | Ufer-Statics auf **Wasserhöhe** | „Ufer-Statics Höhe“ = −5 (vorher 0) |
| offenes Wasser `a8`–`ab` z −5 (97 %) | bleibt | bleibt |
| Strand nach dem Grund: 0, −1…−3 | flacher Strand | „Land-Höhen zum Wasser“ = −3 −1 0 |

Vergleich gebaute 2048²-Karte mit derselben Analyse: Meeresgrund −15 (77 %), Wasser-Statics +10 über dem Grund (100 %),
Strand −3/−1/0 – passt zum Original. Der braune „Graben“ (Tile `0066` von `map2/water2x` ohne Wasser darüber)
ist dadurch abgedeckt.

Die Analyse wertet Zellen mit Wasser-Statics jetzt als Wasser und zeigt zusätzlich die Höhe des Meeresgrunds.

---

## Version 7: CGI-Ansicht – 2D, Kataloge, Küsten- und Wasser-Pinsel

| Neu | Bedienung |
|---|---|
| **Tasten-Hilfe** | Leiste unter der Ansicht zeigt immer die Tasten / Maus-Aktionen des aktuellen Werkzeugs (statt kurzem Tooltip). |
| **2D-Ansicht** | Knopf „2D“ oder Taste **T**: Karte von oben, Land-Tiles als Quadrate, Hänge schattiert. Alle Werkzeuge (Land malen, Bereich, Küste, Wasser, Statics) gehen auch hier. |
| **Bilder-Katalog** | Reiter Items und Land zeigen Vorschaubilder statt Liste (klein / mittel / groß). Klick = auswählen, Doppelklick = Werkzeug aktivieren. „Texturen zeigen“ im Reiter Land. |
| **Großer Katalog…** | Eigenes Fenster (`Dialogs/TilePickerForm`, im Designer öffnbar): Land-Tiles, Texturen, Items mit Suche und Vorschau. |
| **Static finden** | Ausgewähltes Static wird im Item-Katalog markiert. „Im Item-Katalog zeigen + übernehmen“ / Taste **I** übernimmt ID + Hue zum erneuten Setzen. Kopieren / Einfügen auch als Knöpfe. |
| **Pinsel „Küste“** | Über eine Küste ziehen: Meeresgrund (`0064`, −15), äußerer Ring −5, Wasser-Statics −5, Strand −3/−1/0 – wie die Original-map0. Ein Zug = ein Rückgängig-Schritt. |
| **Pinsel „Wasser“** | Wasser-Statics malen (Strg = entfernen), wahlweise mit Meeresgrund darunter. Eigene IDs möglich („= Item aus dem Katalog“). |
| **Transparentes Wasser** | Items mit TileData-Flag `Translucent` werden durchsichtig gezeichnet (wie im Client); der Reiter „Küste / Wasser“ zeigt die Flags der Wasser-IDs. „Wasser durchsichtig“ zeigt alle Wasser-Statics durchsichtig zur Kontrolle. |
| **Bereich** | Mit der Maus aufziehen, dann **F** füllen (Land-Tile), **K** Küste anpassen, **W** Wasser (Umschalt+W entfernen), **G** glätten, Bild↑/↓ heben / senken, Strg+C / Strg+V. Auch als Knöpfe. |
| **Pinsel-Größe** | Oben in der Leiste „Land“ (1 Tile bis 33×33). |

Neue Dateien: `Core/CoastShaper.cs`, `Controls/TileGridView.cs`, `Dialogs/TilePickerForm.cs` (+ `.Designer.cs`).

---

## Version 8: Vorlagen (Gebäude, Böden), Höhlen, Wege

**Vorlagen-Ordner** (Einstellungen → „Vorlagen-Ordner“, Standard `DragonData/Multis`, im Plugin-Ordner): jeder Unterordner ist eine Kategorie.
Mitgeliefert sind die 586 Gebäude aus `Multis.rar` (Fiddler, OLDScript, UOArchitect – Arena, Festungen, Haus, Kirchen, Minen, Schiffe …).

| Format | Lesen | Schreiben |
|---|---|---|
| Dragon-Vorlage `.dmsv.json` | Land-Tiles mit Höhen + Statics + Name/Kategorie | ja |
| UoFiddler-Multi `.txt` (`0xID x y z flag`, auch dezimale IDs alter Skripte) | ja | ja |
| UO Architect `.uoa` (Version 1 und 2) | ja (mit Hue) | ja (Version 1) |
| Weltdatei `.wsc` (`SECTION WORLDITEM`) | ja (absolut → zentriert) | – |
| Sphere `.scp` (`ITEMDEF` mit `COMPONENT=`, oder `WORLDITEM` mit `P=`) | ja | – |

**Reiter „Vorlagen“** (CGI-Ansicht): Kategorie, Suche (Name, Kategorie, Autor), Vorschau, Anzahl Statics und Größe.
„Setzen“ / Doppelklick → halbtransparente Vorschau an der Maus, Klick setzt auf die Boden-Höhe + „Z +“; danach ist alles ausgewählt und mit Pfeilen / Bild↑↓ verschiebbar.
Optionen: Statics, Boden, Boden mit Höhe, Statics an der Stelle vorher löschen.

**Neue Vorlage aus der Karte:** Werkzeug „Bereich“ aufziehen → „Bereich → Vorlage…“ (Boden und/oder Statics) oder Statics auswählen → „Auswahl → Vorlage…“. Name, Kategorie (= Unterordner), Format wählbar. Bereich + **S** wählt alle Statics darin aus.

**Höhle:** Pinsel „Höhle“ – am Fuß des Berges anfangen und hineinziehen; Boden (`0245`–`0249`) auf einer Höhe, Rand wird Wand (Fels-Textur dahinter). „Bereich mit Schwarz (0244) füllen“ für den Dungeon-Bereich.

**Wege / Gebäude-Böden:** Reiter Land → „Aus der Farbtabelle“ (alle Gruppen des Regelsatzes, z. B. cobblestones, marble floor, Dark Wood Floorboards) + „Höhe vom ersten Klick übernehmen“. Mehrere IDs werden zufällig gemischt.

Neue Dateien: `Core/MapTemplate.cs`, `Dialogs/SaveTemplateDialog.cs` (+ Designer), `DragonMapStudioForm.Templates.cs`, `DragonData/Multis/…`.

---

## Version 9: Sprache umschalten – Deutsch / English / Français

* Menü **„Sprache / Language / Langue“** (oder Einstellungen → „0 Sprache / Language“) schaltet die ganze Oberfläche sofort um:
  Menüs, Werkzeugleisten, Reiter, Knöpfe, Tooltips, Einstellungs-Namen und -Beschreibungen, Tasten-Hilfe unter der CGI-Ansicht, Dialoge.
  Die Wahl wird gespeichert.
* Hilfe-Reiter: Deutsch, English und neu Français.
* Übersetzungen liegen als Textdateien in `DragonData/Lang/en.txt` und `fr.txt` (eine Zeile pro Text: `Deutsch<TAB>Übersetzung`).
  Fehlende Texte bleiben deutsch und lassen sich dort einfach ergänzen oder verbessern – auch weitere Sprachen nach demselben Muster sind möglich.
* Noch deutsch: Status- und Log-Meldungen mit Zahlen darin (Logs sind ohnehin zweisprachig DE/EN).

**English:** menu „Sprache / Language / Langue“ switches the whole interface (German, English, French); translation tables in `DragonData/Lang` can be edited.
**Français :** le menu „Sprache / Language / Langue“ change toute l'interface (allemand, anglais, français) ; les tables de traduction dans `DragonData/Lang` sont modifiables.

---

## Version 10: 8 Bit (Dragon) oder 16 Bit (bis 65 536 Farben)

| | 8 Bit (klassisch) | 16 Bit (erweitert) |
|---|---|---|
| Farbadressen | 256 (`00`–`ff`) | bis 65 536 (`0000`–`ffff`), in Seiten zu 256 |
| Gruppen | bis `fe` | bis `7fff` |
| Karten-Datei | 8-Bit-BMP | 16-Bit-PNG (Graustufen = Adresse, verlustfrei, mit anderen Programmen lesbar) |
| maptrans / groups / betweentrans … | 2-stellige Adressen | 4-stellige Adressen |
| mit altem Dragon austauschbar | ja | nein (Import alter Daten geht immer) |

* **Umschalten:** Regeln → „Regelsatz auf 16 Bit umstellen“ (jeder weitere Klick = eine neue Seite mit 256 Farben),
  Bearbeiten → „Karte in 16 Bit umwandeln“, „Neue Karte“ → Häkchen „16 Bit“.
  „Neue Farbe definieren“ bietet 16 Bit an, wenn alle 256 Farben belegt sind; eine Farbe über `ff` in einer 8-Bit-Karte fragt nach.
* **Paletten** im Editor und in der Farbtabelle: „Seite“ bzw. Mausrad blättert durch je 256 Farben.
* **Speichern:** `.bmp` = 8 Bit (nur wenn alle Farben ≤ `ff`), `.png` = 16 Bit. Die Kartenliste zeigt beide.
* Intern speichert der Editor jetzt 16 Bit pro Tile (auch bei 8-Bit-Karten) – doppelter Arbeitsspeicher, dafür ein einziger Codepfad.
* 4-stellige Adressen in Skripten stellen den Regelsatz beim Laden automatisch auf 16 Bit.
* Neue Gruppen brauchen eigene Übergangsdateien (sonst „Regel fehlt“ im Log) und ggf. Items – wie bisher im Reiter „Regeln & Skripte“.

---

## Version 11: Regeln-Werkstatt, Skript-Editor, Vorschau beim Überfahren

**Meldungen beim Laden behoben** – es waren Fehler in den IMod13-Skripten:

| Meldung | Ursache | Korrektur |
|---|---|---|
| Farbe 1e: keine Gruppe | Zeile `1e 01` fehlte in `groups.txt` (Wald Z 40) | ergänzt |
| Farbe 7e: keine Gruppe | Tippfehler `7f 08` statt `7e 08` (Dschungel Z 40) | korrigiert (7f bleibt Höhleneingang) |
| statics/cave2blackRalls.txt fehlt | Tippfehler für `cave2blackWalls.txt` | korrigiert |
| statics/grass2wasteland.txt fehlt | Datei gibt es im IMod13-Paket nicht | Zeile auskommentiert |

Für eigene / gespeicherte Regelsätze: **„Hinweise beheben“** ordnet Farben ohne Gruppe zu (gleiche Tiles) und leitet Regeln mit fehlender Datei auf eine ähnlich benannte Datei um bzw. schaltet sie aus.

**Reiter „Regeln & Skripte“** – farbige Leiste oben:
* **Format 8 Bit / 16 Bit** (aktives Format farbig hervorgehoben; bei 16 Bit fügt ein weiterer Klick eine Seite mit 256 Farben hinzu).
* **+ Neue Farbe…** (auch Doppelklick auf eine Farbe): Adresse mit frei/belegt-Prüfung, Name, Kategorie, RGB mit Prüfung auf doppelte Farben („Eindeutig machen“), Gruppe (oder neue), Höhe, Land-Tiles mit Katalog und Vorschau. Die Farbe ist sofort zum Zeichnen verfügbar.
* **+ Neue Gruppe…** (nächste freie Nummer), **+ Neue Übergangsregel…** mit Beispiel-Datei (12 Standard-Muster als Bild erklärt).
* **Prüfen** (doppelte RGB-Farben, fehlende Gruppen/Dateien), **Hinweise beheben**, **Skript-Editor…**
* **Name + Speichern**: der Regelsatz wird unter seinem Namen in `Dokumente\DragonMapStudio\Regeln` gespeichert und beim nächsten Start geladen.
* Rechts: Hilfe mit Beispielen zum gewählten Unter-Reiter.

**Vorschau beim Überfahren** einer Farbe (Farbtabelle, Paletten im Editor und im Reiter Farbtabelle): Land-Tiles/Texturen, Items der Gruppe, Statics der Übergänge – unter der Zeile, damit sie sichtbar bleibt.

**Skript-Editor** (`Dialogs/ScriptEditorForm`, auch Menü Regeln): alle Skript-Dateien als Text, Suche, Speichern mit `.bak`; rechts die Bedeutung der aktuellen Zeile (Farbe, Gruppe, Tiles/Statics als Bilder, Muster als 3×3-Bild), unten Syntax und Beispiel des Dateityps. Nach dem Speichern werden die Regeln auf Wunsch neu eingelesen.

Neue Dateien: `Core/RuleSetTools.cs`, `Controls/ColorPreviewPopup.cs`, `Dialogs/ColorDefinitionDialog`, `Dialogs/GroupDialog`, `Dialogs/TransitionRuleDialog`, `Dialogs/ScriptEditorForm` (jeweils mit `.Designer.cs`), `DragonMapStudioForm.RulesUi.cs`.

## Höhleneingänge in der CGI-Ansicht

So baut Ultima Online einen Höhleneingang (Original-Karte, Dragon/IMod13 `map/cave-enti2mountain.txt`):

| Tile | Bedeutung (A = Eingang, B = Berg) |
|------|-----------------------------------|
| `01DB` | schwarzer Mund (begehbar; Dragon-Gruppe 1a) |
| `0002` | unsichtbarer Mund (Dragon-Gruppe 1d) |
| `01DA` / `01D6` | Berg im Westen / im Osten |
| `01D8` / `01D4` | Berg im Süden / im Norden (`01D4` +5…15 höher) |
| `01D3` `01D5` `01D7` `01D9` | Ecken (SO / SW / NW / NO), teils +5…15 höher |

Die offene Seite (zum flachen Land) bekommt keinen Übergang – das ist gewollt. Eine echte „Unterwelt“ gibt es in UO nicht: dahinter wird entweder mit dem Pinsel **Höhle** weitergegraben (Boden `0245`–`0249`, Rand wird Fels-Wand) oder auf dem Server ein Teleporter in den Dungeon-Bereich gesetzt (x > 5119, Rest mit Schwarz `0244`).

**Pinsel „Eingang“** (Leiste Land, Reiter „Höhle / Weg“): am Fuß des Berges auf der Bodenhöhe klicken und 2–3 Tiles in den Hang ziehen. Jede Zelle wird Mund (`01DB`, oder `0002` mit „Eingang unsichtbar“), danach bekommt jede Eingangs-Zelle mit Berg-Nachbarn ihr Rand-Tile aus der Regel-Datei (fehlt sie: eingebaute Kopie). Als Berg zählt ein Nachbar mit Tile der Berg-Gruppe (Generator → Berg-Gruppe) oder einer, der mind. 5 höher liegt.

**Mund-Höhe** (Standard 20): Der Mund liegt so viel über dem Boden des ersten Klicks. Wie im Original wird das schwarze Tile dadurch als steile Wand in den Hang gezogen (Bogen-Form) statt flach auf dem Boden zu liegen. Sichtbar ist das nur, wenn der Eingang nach **Süden oder Osten** zeigt – die Kamera schaut von Südosten.

**Höhlen-Tiles (Galerie im Reiter „Höhle / Weg“):** alle Land-Tiles, deren TileData-Name „cave“ enthält, dazu die bekannten (`0002`, `01D3`–`01DE`, `0244`–`0249`) und **eigene IDs** (Feld „Eigene IDs“ oder „+ Tile“, wird in den Einstellungen gespeichert). „Texturen zeigen“ zeigt die Textur, mit der das Tile am Hang gezeichnet wird. Doppelklick = Land-Pinsel, „→ Höhlenboden“ nimmt das Tile in den Höhlen-Pinsel, „→ Eingang (Mund)“ nimmt es als Mund für den Eingang-Pinsel.

**Eingangs-Muster:** einen fertigen Eingang (z. B. aus der Original-Karte) mit dem Werkzeug „Bereich“ samt etwas Boden davor markieren, „Bereich → Muster“ speichert ihn als Vorlage im Ordner `Höhleneingang` (Land-Tiles + Höhen relativ zum Anker). „Muster setzen“ / Doppelklick: Klick auf den Boden vor einem Berg setzt ihn mit allen Höhen.

**Vorderkante unsichtbar** (an): Wie im Original (im Client als „NO DRAW“ zu sehen) wird die vordere Reihe des Mundes – die Zellen, die direkt an den flachen Boden grenzen – zum unsichtbaren Tile `0002` auf Bodenhöhe. Dadurch reicht die schwarze Wand dahinter bis auf den Boden. Davor am besten einen Erdweg (Reiter Land, Erde) mit „Höhe vom ersten Klick“ malen.

Korrekturen am Pinsel **Höhle**: nur Land, das schon über dem Boden liegt, wird zur Wand (vorher wurde auch der Boden vor dem Eingang zu einem Wall angehoben), und Boden aus einem früheren Zug auf anderer Höhe wird nicht mehr zur Wand.

## Höhlen-Stempel (Reiter „Höhlen-Stempel“)

**So ist ein Eingang in der Original-Karte gebaut** (ausgewertet aus der CGI-Ansicht mit „ID + Höhe + Textur“, Höhen über dem Boden davor):

Nach Süden (Berg im Norden), Spalten: Rahmen links | Mund × 3 | Rahmen rechts

| Reihe | Tiles | Höhe |
|-------|-------|------|
| oben (2. Bergreihe) | `01D3` · `01D4 01D4 01D4` · `01D5` | +30 … +37 |
| Mund (1. Bergreihe) | `01DA` · `01DB 01DB 01DB` · `01D6` | Rahmen +10 … +20, Mund +17 … +25 |
| vorn (1. Bodenreihe) | `01E6` · `01DF 01DF 01DF` · `01E4` | Boden (Übergang Höhle → Erde, `cave2dirt.txt`) |
| davor | Erde `0071`–`0078` | Boden |

Auf jedem Tile der Mund-Reihe liegt ein unsichtbares Static („NO DRAW“) auf Bodenhöhe. Neben den Rahmen liegt Fels (z. B. `00DF`) mit etwa +12 … +16.

Nach Osten (Berg im Westen) genauso gedreht: oben `01D3` · `01DA …` · `01D9`, Mund `01D4` · `01DB …` · `01D8`, vorn `01E7` · `01DD …` · `01E4`.

Alle Tiles haben eine eigene Textur (Textur-ID = Land-ID), am Hang zeichnet der Client also die Textur.

Der Stempel baut genau dieses Raster. **Ziehen:** unten am Rahmen anfangen und schräg nach oben zur anderen oberen Ecke ziehen. Der Abstand entlang der Wand ergibt die Breite (Start und Ende sind die Rahmen), die Höhe am Ende des Zuges die Höhe der oberen Reihe. Mund und Rahmen werden im selben Verhältnis angepasst.

**Varianten** (Einstellung „Variante“, alle drei kommen in der Original-Karte vor):
* **Original** – schwarzer Mund, Übergangsreihe `01E6/01DF/01E4`, Erdweg davor.
* **Ohne Weg** – schwarzer Mund direkt auf dem Boden, das Gras davor bleibt.
* **Unsichtbar** – Mund `0002` mit Höhlenboden `0245`–`0249` davor (wie innen im Dungeon).

**Übergänge** (`Core/LandTransitions.cs`): Nach dem Stempeln werden die Map-Übergänge des Dragon-Regelsatzes rund um den Eingang neu gesetzt: Gras → Erde (`0083`, `0086`, `0087`, `0089`, `007E` …) und Berg → Erde (`00DF`, `06F2` …), wie im Original. Jedes Land-Tile wird dazu seiner Gruppe zugeordnet (Farbtabelle + Übergangsdateien). Das geht auch für beliebige Bereiche: Werkzeug „Bereich“, markieren, **T** – z. B. nach dem Malen einer Straße.

**Entfernen:** Strg+Klick mit dem Höhlen-Stempel auf einen Eingang – Mund, Rahmen und obere Reihe werden wieder Berg (Höhe aus dem Berg drumherum), die Vorderreihe wird Boden, die NODRAW-Statics werden gelöscht, danach Übergänge neu.

**Eigene Stempel:** einen fertigen Eingang mit „Bereich“ markieren und „Bereich → speichern“ (Vorlagen-Ordner `Höhleneingang`). Die Liste „Gespeicherte Stempel“ setzt ihn mit Land, Höhen (relativ zum Boden) und Statics wieder.

### Höhleneingänge im 2D-Editor und im Generator

* Werkzeug **„Höhle“** in der Leiste des Karten-Editors: neben einen Berg klicken, dessen Süd- oder Ostseite an Boden grenzt. Gemalt werden Farben: obere Reihe + Mund-Reihe = Gruppe „Höhleneingang schwarz (01DB)“ (Höhe Boden + 20), davor Höhlenboden (Gruppe 03), daneben und davor Erde (Gruppe 09). **Umschalt+Klick** = unsichtbare Variante (Gruppe 1d), **Rechtsklick** = Eingang wieder Berg.
* Fehlt die Gruppe „Höhleneingang schwarz (01DB)“, wird sie angelegt (nächste freie Gruppe, 3 Farben mit Höhe 10 / 20 / 30, Tile `01DB`), dazu die Regeln Eingang → Berg (`map/cave-ent2mountain.txt`) und 03 → 09 (`map/cave2dirt.txt`). Mit „JSON speichern“ / „Als Dragon-Skripte exportieren“ dauerhaft machen.
* Beim Bauen entsteht daraus genau das Original-Raster: `01D3/01D4/01D5` (+26…34), `01DA/01DB/01D6` (+20), `01E6/01DF/01E4`, daneben `00DF`, weiche Gras-Erde-Kanten. Die Build-Option **„Höhleneingang: NODRAW-Statics“** setzt das unsichtbare Static `0001` auf jedes Tile der Mund-Reihe.
* **Generator:** „Höhleneingang wie Original“ (an) setzt die Eingänge mit diesem Stempel an geraden Bergseiten nach Süden / Osten, aus = unsichtbare 2×2-Eingänge (Gruppe 1d) wie bisher.

**Bereich auswerten:** Werkzeug „Bereich“, mit der linken Maustaste ein Viereck ziehen, dann **L** drücken (oder den Knopf im Reiter). Das Log wird als Datei gespeichert **und in die Zwischenablage kopiert**.

Ein Klick auf den Boden direkt vor einer Bergwand (Süd- oder Ostseite) setzt einen kompletten Eingang (`Core/CaveEntranceBuilder.cs`):

1. **Boden und Berg werden am Tile erkannt**, nicht an der Höhe: Berg = Berg-Gruppe der Farbtabelle + Berg-Pinsel-Tiles + alle Land-Tiles mit „mountain“ / „rock“ im TileData-Namen. Alles andere (Gras, Erde, Sand …) ist Boden – auch wenn es höher liegt.
2. **Höhlenboden = Höhe des Bodens davor** (Mittelwert über die Breite des Mundes).
3. Vordere Reihe (erste Bergreihe): `0002` auf Bodenhöhe – der Client zeichnet Land `0000`–`0002` nicht.
4. Hintere Reihe(n): Rand-Tiles `01D3`–`01DA` nach `map/cave-enti2mountain.txt`, bis zur **Mund-Höhe** angehoben. Ist der Berg dahinter zu niedrig, wird er angehoben („Berg anheben“).
5. Davor ein Weg (Standard Erde `0071`–`0078`, 2 Tiles) auf Bodenhöhe.

Einstellungen: Richtung (Auto / Süden / Osten), Breite, Tiefe, Mund-Höhe, Berg anheben, Weg-Länge, Weg-Tiles, Weg-Breite. Sie werden gespeichert.

**Rahmen** (an): links und rechts vom Mund je eine Spalte Rahmen-Tiles (`01DA` / `01D6`, hinten die Ecken `01D3` / `01D5`). Die Vorderkante hat dann genau „Breite“ unsichtbare Tiles – wie die Reihe „NO DRAW“ im Original.

**Ziehen statt Klicken:** Maus auf den Boden an einer Seite des Mundes, gedrückt halten, zur anderen Seite ziehen = Breite. Endet der Zug oben an der Bergwand, wird die Höhe des Tiles dort die Mund-Höhe. Während des Ziehens zeigt die Ansicht „Breite x, Höhe y“.

**Infos einblenden:** Leiste oben „Höhen“ + Auswahl daneben: Höhe, Land-ID (hex), ID + Höhe, ID + Höhe + Textur-ID.

**Bereich auswerten → Log** (Reiter Höhlen-Stempel): einen Eingang, eine Straße oder einen Bergrand mit „Bereich“ markieren und auswerten. Das Log `cgi_bereich_<x>_<y>_<b>x<h>.txt` (Log-Ordner) enthält:
* alle Land-IDs mit Anzahl, Klasse (Berg / Boden / Eingang / unsichtbar), Textur-ID, Radar-Farbe, TileData-Flags und Name,
* Raster mit Land-ID, Höhe, Textur-ID, Klasse und „wie gezeichnet“ (Textur am Hang / Land-Bild flach / gar nicht),
* für jedes Eingangs- und unsichtbare Tile das 8-Nachbar-Muster wie in den Dragon-Dateien,
* alle Statics mit Lage, Höhe über dem Land, Hue, Flags und Name.

Damit kann man Eingänge, Straßen und Bergränder aus der Original-Karte auswerten und nachbauen.

**Zeichnen wie der Client** (aus dem ClassicUO-Quellcode, `Land.ApplyStretch`):
* Ein Land-Tile wird mit seiner **Textur** gezeichnet, sobald irgendeine der 12 Höhen um es herum abweicht und die Textur existiert.
* Sonst – auch am Hang, wenn es keine Textur hat – wird das **Land-Bild flach** auf der Tile-Höhe gezeichnet. Vorher hat die Ansicht das Land-Bild am Hang verzerrt.
* Land `0000`–`0002` wird nicht gezeichnet. In der Ansicht ist es gelb gestrichelt umrandet (abschaltbar).
* „Texturen auch auf flachem Land zeigen“ ist eine reine Vorschau: so sieht man die Textur, die am Hang benutzt würde.

Der Höhle-Pinsel macht nur noch **Berg-Tiles** zur Wand. Gras daneben bleibt Boden, auch wenn es höher als der Höhlenboden liegt.

## Berge in der CGI-Ansicht (Reiter „Berg“)

* **Pinsel „Berg“** (Leiste Land): am Fuß klicken und ziehen. Der Berg steigt ab der Bodenhöhe des ersten Klicks (oder „Fuß-Z“, wenn „Fuß automatisch“ aus ist) um „Steilheit“ Z pro Tile bis „Gipfel-Z“. Pinsel-Größe oben = Breite. Mehrmals ziehen baut einen Grat (mit „Nur anheben“ wird nie etwas abgesenkt).
* **Bereich + M** (oder Knopf „Markierten Bereich zum Berg formen“): die ganze markierte Fläche wird ein Berg – der Rand ausgefranst, innen Kuppen und Täler, Felskanten durch „Rauheit“.
* Einstellungen: Gipfel-Z (Standard 90 wie Dragon-Gruppe 06), Steilheit, Hügel-Größe / -Stärke, Rauheit, Rand ausfransen, Berg-Tiles (Standard `022c`–`022f`, leer = Berg-Gruppe der Farbtabelle), optional Fuß-Tiles für die äußerste Reihe, Zufalls-Zahl. Werden in den Einstellungen gespeichert.
* Danach mit „Eingang“ den Höhleneingang an der Süd- oder Ostseite setzen.

Im 2D-Editor: werden Farben der Gruppe 1d von Hand gemalt, aktiviert „MUL erzeugen“ / „CGI-Karte bauen“ jetzt die Regel 1d → Berg selbst (vorher nur der Generator).

## CGI-Ansicht: neue Seitenleiste

* **Kartenübersicht** als aufklappbarer Abschnitt, Knöpfe im Kopf: **−** / **+** zoomen, **↕** Größe klein / mittel / groß, **⧉** in ein eigenes Fenster abdocken (Fenster schließen = wieder andocken). In der Übersicht: Mausrad = Zoom um den Mauszeiger, rechte Taste ziehen = schieben, Doppelklick rechts = ganze Karte, Klick links = hinspringen. Gezoomt folgt sie der Ansicht. Das Übersichtsbild ist jetzt bis 1024 Pixel groß (vorher 320), dadurch bleibt es beim Zoomen scharf. Gilt auch für die Übersicht im Karten-Editor.
* **Gehe zu** aufklappbar.
* Statt zwei Reihen Reiter: **farbige Kategorien mit Bildern** – Bauen (Items, Multis, Vorlagen), Gelände (Land, Küste / Wasser, Berg), Höhlen (Höhle / Weg, Höhlen-Stempel), Prüfen (Auswahl, Probleme). Die Bilder sind Land- / Item-Grafiken aus den Client-Dateien (ohne Client-Dateien ein farbiger Buchstabe).
* Die Reiter **Höhle / Weg**, **Höhlen-Stempel** und **Berg** bestehen aus aufklappbaren Abschnitten (Werkzeug, Einstellungen, Ansicht, Auswerten, Gespeicherte, Hilfe). Die Hilfe ist zu Beginn zugeklappt. Welche Abschnitte offen sind, wird gespeichert.
* **Höhlen-Stempel → Vorschau:** zeigt das Raster der gewählten Variante mit den echten Tile-Bildern, IDs und Höhen.
* Die Seitenleiste ist breiter (der Trenner lässt sich weiter ziehen, mindestens 300 Pixel).

## Karten-Editor: neue Seitenleiste

* **Kartenübersicht** oben wie in der CGI-Ansicht: aufklappbar, **−** / **+** / Mausrad = Zoom, rechte Taste = schieben, **↕** Größe, **⧉** abdocken. Übersichtsbild bis 768 Pixel.
* **Karten (Projekt-Ordner)** aufklappbar.
* **Werkzeug „Höhle“** (zu Beginn zugeklappt): Einstellungen des Höhleneingangs im 2D-Editor (Breite, Mund über Boden, Gruppen, Weg-Länge, unsichtbar).
* **Farben** füllen den Rest; die Kopfzeile klappt sie ein und aus.

## Fehler behoben: Generator → Karten-Editor (aktuelle Karte)

Mit „aktuelle Kartengröße benutzen“ wurde nur die **obere Hälfte** der erzeugten Karte in die geöffnete Karte kopiert. Unten blieb die alte Karte stehen, deshalb war eine harte Kante quer durch die Karte zu sehen. Ursache: `Buffer.BlockCopy` zählt Bytes, die Karte hat aber 2 Byte pro Pixel (16-Bit-Farbadressen). Jetzt wird mit `Array.Copy` kopiert. Derselbe Fehler steckte in **„Karte reparieren“** und ist dort auch behoben. Der Generator selbst rechnet richtig: Vorschau und volle Größe stimmen zu 96–100 % überein, die Abweichungen sind nur feine Details.

## Karten-Editor: Pinsel-Katalog, Info, Farb-Stempel, CGI-Vorschau, Kontextmenü

Seitenleiste von oben nach unten (jeder Abschnitt auf- und zuklappbar):

* **Farbe unter der Maus / Pipette:** Farbfeld, Adresse, Name, Gruppe, Höhe, Tiles und die Land-Bilder dieser Tiles. Folgt der Maus. Mit der Pipette (I) bleibt die aufgenommene Farbe stehen (✔), und sie wird im Katalog markiert.
* **Pinsel-Katalog:** alle definierten Farben nach Gruppe, mit Kategorie (Gras & Wald, Wasser & Küste, Berg & Fels, Wege & Straßen, Hausböden, Höhle & Dungeon, Sonstiges), Farbfeld und Höhe. Auswahl der Kategorie + Suche (Name, Gruppe, Hex). Links = Farbe 1, rechts = Farbe 2, Doppelklick = Pinsel. Beim Überfahren: Gruppe, Höhe, Tiles. Selbst definierte Farben erscheinen automatisch.
* **Bereich: CGI-Vorschau & Farb-Stempel:**
  * „Bereich markieren“ = Werkzeug Auswahl (S); die Markierung wird nicht in die Karte gemalt.
  * **„Auswahl → CGI-Vorschau“** (auch Taste **V**, Kontextmenü oder der braune Knopf **▶ CGI-Vorschau** in der Werkzeugleiste): baut nur den markierten Bereich (+ 8 Tiles Rand für die Übergänge, höchstens 512×512) im Speicher und zeigt ihn in einem eigenen CGI-Fenster (Raster, Infos ID / Höhe / Textur, Zoom, „Neu bauen“). Die Karte und die große CGI-Ansicht bleiben unverändert. Ohne Auswahl: 128×128 um die Bildmitte.
  * **„Auswahl → Stempel speichern“:** speichert den Ausschnitt als Farb-Stempel (`<Vorlagen-Ordner>\Farbstempel\*.dmstamp.json`). Jedes Pixel merkt sich Farbe, Gruppe und Höhe relativ zum Boden des Stempels (Median des Randes, Wasser ausgenommen).
  * **„Stempel setzen“** / Doppelklick: der Stempel hängt an der Maus, jeder Klick setzt ihn (ein Rückgängig-Schritt je Klick), rechte Taste = fertig. Mit **„Höhen an den Boden anpassen“** bekommt jedes Pixel die Farbe seiner Gruppe mit der passenden Höhe zum Boden an der Zielstelle – ein auf Höhe 0 gebauter Hausboden passt so auch auf ein Plateau in Höhe 20.
* Karten (Projekt-Ordner), Werkzeug „Höhle“, Farben (die lange Farbtabelle ist zu Beginn zugeklappt).

**Kontextmenü:** rechte Maustaste mit Auswahl, Hand oder Pipette – oder **Umschalt + rechte Taste** mit jedem Werkzeug. Inhalt: Farbe an dieser Stelle (als Farbe 1 / 2, in der Farbtabelle zeigen), Rückgängig / Wiederholen, CGI-Vorschau, Stempel speichern, Kopieren / Ausschneiden / Einfügen / Füllen, Werkzeug wechseln, hier in der CGI-Ansicht öffnen.

Rückgängig / Wiederholen gab es schon (Strg+Z / Strg+Y, Leiste, Menü Bearbeiten) – jetzt auch im Kontextmenü. Höhen: Werkzeuge „Höhe +“ / „Höhe −“ wechseln innerhalb der Gruppe die Farbe; Straßen, Wege, Hausböden und Küsten malt man mit den Farben aus dem Katalog – die Übergänge macht der Compiler (in der CGI-Vorschau sofort zu sehen).

Im Fenstertitel steht jetzt `[Stand 21.11.2026 – Editor 8]`.

## CGI-Ansicht → Farben: Stempel aus gebauten Karten, ganze Karte zurück in Farben

In der CGI-Ansicht mit den Werkzeugen Land (Land-Tiles / Texturen), Items, Multis und Vorlagen bauen – oder eine andere Karte laden (MUL / UOP) und dort etwas markieren. Die beiden Knöpfe stehen ganz links in der **oberen Werkzeugleiste der CGI-Ansicht** (grün **„▣ Bereich → Farb-Stempel“**, blau **„▤ Karte → Farbkarte“**); mit dem Werkzeug „Bereich“ geht der Stempel auch mit der Taste **P**. Dieselben Knöpfe gibt es zusätzlich im Reiter Höhlen-Stempel → „In Farben umwandeln“:

* **„Markierten Bereich → Farb-Stempel…“** (vorher mit „Bereich“ markieren): Name, Kategorie, Statics-Art, Art für fehlende Farben wählen. Der Stempel landet im Ordner `Farbstempel` und erscheint im Karten-Editor (Stempel-Menü, Abschnitt Stempel). Ein Bericht wird als `cgi_stempel_<Name>.txt` im Log-Ordner gespeichert.
* **„Ganze Karte → Farbkarte (Karten-Editor)…“:** die ganze CGI-Karte wird zur Farbkarte mit Statics-Ebene (z. B. die Original-Karte zum Nachbauen oder zur Fehlersuche). Bericht: `cgi_karte_zu_farben.txt`.

**So wird umgewandelt** (`Core/CgiToColor.cs`), für jedes Land-Tile mit seiner Höhe:
1. Eine Farbe, deren Tiles das Tile enthalten und deren Höhe höchstens 4 abweicht.
2. Ein Übergangs-Tile einer Regel (z. B. Gras → Erde) → die Zellgruppe der Regel (der Compiler macht den Übergang wieder).
3. Tiles, die der Compiler selbst setzt (Meeresgrund `0064` der Küste) → Wasser-Gruppe.
4. Sonst je nach Einstellung **„Fehlende Farben“**:
   * **Vorschlag + Bestätigen (empfohlen):** Liste mit Tile, Höhe (in 5er-Schritten), Anzahl, TileData-Name, Radar-Farbe und Gruppe (eine vorhandene Gruppe mit gleichem Tile-Namen oder eine neue, Name änderbar). Angehakte werden als neue Farben angelegt (Farbe = Radar-Farbe, eindeutig gemacht; Kategorie „Aus CGI“).
   * **Automatisch anlegen:** dasselbe ohne Nachfrage.
   * **Nur vorhandene Farben:** die Farbe, deren Tile die ähnlichste Radar-Farbe hat (und die passende Höhe).
   Neue Farben / Gruppen mit „JSON speichern“ / „Als Dragon-Skripte exportieren“ dauerhaft machen.

**Statics** (Einstellung „Statics“):
* **Statics-Ebene (empfohlen):** alle Statics 1:1 (Lage, Höhe über dem Land, ID, Hue). Beim Stempeln im Karten-Editor kommen sie in die **Statics-Ebene** der Karte (`<Karte>.statics.bin` neben der Karte, wird mit der Karte gespeichert, umbenannt und mit Strg+Z / Strg+Y zurückgenommen). Ab Zoom 2 als kleine orange Quadrate sichtbar. Beim Bauen (MUL erzeugen, CGI-Karte bauen, CGI-Vorschau) setzt der Compiler sie auf die gebaute Landhöhe.
* **Nur Land:** Statics weglassen.
* **Dragon-Item-Regel:** alle Statics als eine Item-Gruppe in `items/stamp_<name>.txt` (relativ zur Mitte) und eine Regel für die häufigste Gruppe des Bereichs (Chance 1) – Dragon setzt sie dann zufällig.

Eine **ganze umgewandelte Karte** bekommt eine *vollständige* Statics-Ebene mit absoluten Höhen: beim Bauen setzt Dragon dann keine eigenen Statics dazu (keine Übergangs-Statics, Items, Wasser-, NODRAW-Statics) – sonst wären sie doppelt.

**Test** (Generator-Karte 512×512 bauen → zurück in Farben → wieder bauen, mit dem Regelsatz im Repo): 97,7 % gleiche Tile-Gruppe, 99,4 % Höhe ±3, alle 32.787 Statics identisch (Lage, Höhe, ID, Hue). Abweichungen nur bei Gruppen mit denselben Tiles (Gras / Wald, Sand / Wüste) – gebaut ergibt das dasselbe Tile.

### Stempel-Menü im Karten-Editor

Knopf **„▦ Stempel-Menü“** in der Werkzeugleiste: alle Farb-Stempel als Bilder (Farben, Statics als orange Punkte), Kategorie-Auswahl, Suche, „Höhen an den Boden anpassen“, Setzen / Löschen / Ordner / Neu laden.
* Mit **mehreren Monitoren** öffnet es sich als **eigenes Fenster** (auf dem anderen Monitor), mit einem Monitor als **Leiste rechts** neben der Karte.
* **⧉** im Kopf: Fenster ↔ Leiste. **Fenster schließen** = es kommt als Leiste rechts zurück. **✕** blendet es aus.

Im Fenstertitel steht jetzt `[Stand 22.11.2026 – Stempel 11]`.


## Stempel-Ordner, einmal / mehrfach setzen, CGI aktualisieren, CGI-Bereich in die Farbkarte

**Wo liegen die Farb-Stempel?** Standard: `<Projekt-Ordner>\Farbstempel\*.dmstamp.json`. Anderer Ordner: Einstellungen → „Farbstempel-Ordner“ oder im Stempel-Menü **„Ordner wählen…“** (die vorhandenen Stempel werden auf Wunsch verschoben oder kopiert). **„Hinzufügen…“** kopiert Stempel-Dateien aus einem beliebigen Ordner (anderes Projekt, Download) in den Stempel-Ordner. Bis „Stempel 10“ lagen sie im Vorlagen-Ordner (`Multis\Farbstempel`) – beim ersten Start werden sie automatisch in den neuen Ordner verschoben.

**Fehler behoben – eigene Multis / Vorlagen fehlten:** Die Vorlagen-Liste hat die Farb-Stempel im Vorlagen-Ordner als Vorlagen mitgelesen (`*.dmstamp.json` endet auf `.json`), darunter riesige Stempel mit zehntausenden Statics. Jetzt werden `*.dmstamp.json` nie als Vorlage gelesen, und die Stempel liegen nicht mehr im Vorlagen-Ordner.

**Einmal oder mehrfach setzen:** Häkchen **„Mehrfach setzen“** (Stempel-Menü und Abschnitt „Bereich: CGI-Vorschau & Farb-Stempel“). Aus = der Stempel verlässt nach einem Klick die Maus. **„Abbrechen“**, Esc, rechte Taste oder Kontextmenü „Stempeln / Einfügen beenden“ beendet das Stempeln. Strg+V (Einfügen) bleibt mehrfach.

**CGI aktualisieren (Karten-Editor):** grüner Knopf **„⟳ CGI aktualisieren“** in der Werkzeugleiste (auch im Kontextmenü). Gebaut wird nur der sichtbare Teil der Farbkarte (oder die Auswahl, höchstens 1024×1024, mit 8 Tiles Rand für die Übergänge) und in die CGI-Karte übernommen – der Rest der CGI-Karte bleibt, das geht viel schneller als die ganze Karte. Hat die CGI-Karte eigene Änderungen (in der CGI-Ansicht gesetzte Statics / Land) oder stammt sie nicht aus dieser Farbkarte, fragt das Programm: **Ja** = vorher den CGI-Bereich in die Farbkarte übernehmen (nichts geht verloren), **Nein** = trotzdem aktualisieren, **Abbrechen**.

**CGI → Farbkarte, ohne die Farbkarte zu löschen:**
* Neuer Knopf **„▧ Bereich → in Farbkarte“** in der CGI-Leiste: der markierte Bereich wird an **derselben Stelle** in die geöffnete Farbkarte geschrieben (Farben + Statics-Ebene in diesem Bereich), alles andere bleibt. Ein Rückgängig-Schritt im Karten-Editor.
* **„▤ Karte → Farbkarte“** fragt jetzt, wenn eine gleich große Farbkarte offen ist: **Ja** = in die geöffnete Farbkarte schreiben (Rückgängig möglich), **Nein** = als neue Karte, **Abbrechen**.

## Regeln und Skripte lernen (aus der CGI-Ansicht oder aus einem Stempel)

Aus einem gebauten Stück Karte – z. B. aus der Original-Karte – lernt das Studio Dragon-Regeln, so wie man sie von Hand aus der Karte ablesen würde (`Core/RuleLearner.cs`):

* **Map-Übergänge:** für jede Zelle am Rand zwischen zwei Gruppen (A = eigene Gruppe, B = Nachbargruppe) das 8-Nachbar-Muster und das Tile, das dort liegt, mit Höhenversatz → `map/lernen_<name>_<A>_zu_<B>.txt` + Regel in `betweentrans.txt`. Pro Muster werden nur Tiles genommen, die mindestens 15 % der Beispiele ausmachen (der Rest stammt von anderen Regeln). Gibt es für das Paar schon eine Regel, behält sie Vorrang – die gelernte füllt nur die fehlenden Muster. Ein neues Paar kommt vor die allgemeinen Regeln seiner Gruppe.
* **Items:** Statics auf Zellen mitten in einer Gruppe (alle 8 Nachbarn gleiche Gruppe), pro Zelle als Gruppe gestapelter Statics mit Häufigkeit → `items/lernen_<name>_<A>.txt` + Zeile in `items.txt` mit der gemessenen Dichte (Promille).
* **Static-Übergänge:** Statics auf Randzellen → `statics/lernen_<name>_<A>_zu_<B>.txt` + Regel in `statbetweentrans.txt` (Höhe wie der Compiler: tiefstes Land der Gruppe A drumherum).

**Wo:**
* CGI-Ansicht: mit „Bereich“ markieren, violetter Knopf **„✦ Regeln lernen“** ganz links in der oberen Leiste. Land-Tiles ohne Farbe werden vorher als neue Farben vorgeschlagen (damit ihre Gruppe mitgelernt werden kann).
* Karten-Editor: Stempel-Menü → Stempel wählen → **„Regeln lernen…“** (nur Stempel, die ab „Lernen 12“ in der CGI-Ansicht erstellt wurden – sie speichern die gebauten Land-Tiles mit).

**Dialog:** Auswahl **Beides / Nur Land / Nur Statics / Eigene** (Map-Übergänge, Items, Static-Übergänge einzeln), „Mindestens Beispiele je Muster“, Name der Dateien, „Lernen“. Die Liste zeigt jede gelernte Datei mit Anzahl der Muster / Beispiele; darunter der Inhalt (Muster, Tiles, Z, Item-Zeilen). Angehakte werden mit „Angehakte übernehmen“ in den Regelsatz übernommen. Danach **„Als Dragon-Skripte exportieren“** (oder „JSON speichern“) – dann gelten sie für MUL erzeugen, die CGI-Ansicht und den Generator. Bericht: `gelernt_<name>.txt` im Log-Ordner.

**Test** mit dem Regelsatz im Repo: Regel Gras → Sand (`map/grass2sand.txt`) aus dem Regelsatz entfernt, aus einer gebauten Karte neu gelernt, neu gebaut: **99,8 %** der Gras-Sand-Randzellen bekommen wieder ein Tile aus dem Original-Muster (ohne die Regel: 0 %). Export als Dragon-Skripte und erneutes Einlesen: alle gelernten Dateien und Regeln kommen wieder an.

Im Fenstertitel steht jetzt `[Stand 22.11.2026 – Lernen 12]`.

## Vorlagen (Multis) → Farb-Stempel

Reiter **Vorlagen** der CGI-Ansicht, zwei neue Knöpfe unten:
* **„→ Farb-Stempel“**: die gewählte Vorlage.
* **„Liste → Farb-Stempel“**: alle Vorlagen, die die Liste gerade zeigt (z. B. die ganze Kategorie „Fiddler/Haus“).

Abfrage vorher:
* **Boden:** *nicht ändern (durchsichtig)* – der Stempel setzt nur die Statics, die Farbkarte behält ihre Farben; *Farbe 1 des Karten-Editors unter den Statics*; *Farbe 1 im ganzen Rechteck*. Vorlagen mit eigenem Land (Dragon-Vorlagen `.dmsv.json`) bringen ihr Land als Farben mit.
* **Land-Tiles ohne Farbe:** ähnlichste vorhandene Farbe oder neue Farben automatisch anlegen.

Die Statics behalten ihre Höhe über dem Boden; beim Setzen im Karten-Editor passen sich die Farben dem Boden an (Häkchen „Höhen an den Boden anpassen“). Kategorie des Stempels = Ordner der Vorlage; die Stempel werden in einem Unterordner je Kategorie gespeichert (`Farbstempel\Fiddler_Haus\…`), das Stempel-Menü liest auch Unterordner.

**Durchsichtige Stempel-Pixel** (`0xFFFF`): sie lassen beim Setzen die Farbe der Karte stehen; in Vorschauen dunkelgrau, im Stempel-Bild leer.

Test mit den mitgelieferten Vorlagen: 556 Vorlagen gelesen, z. B. `Arenasand03` (5.804 Statics, ohne Land) → Stempel 49×51 mit 5.804 Statics; mit Boden „unter den Statics“ auf Boden 20 gesetzt bekommt der Boden die Höhe 20, der Rest bleibt durchsichtig.

Im Fenstertitel steht jetzt `[Stand 22.11.2026 – Vorlagen 13]`.

## Muster-Pinsel: Stempel einmal oder freihand (Straßen, Wege, Flüsse)

Ablauf: eine fremde Karte in der CGI-Ansicht laden (MUL / UOP), ein Stück Straße / Fluss / Weg mit „Bereich“ markieren, **„▣ Bereich → Farb-Stempel“**. Im Dialog jetzt auch **„Zeichnen: Einmal (Stempel) / Freihand (Pinsel)“**. Der Stempel speichert Farben, gebaute Land-Tiles mit Höhen und Statics.

**Freihand** heißt: der Stempel ist ein Muster, das wie eine Textur lückenlos weiterläuft – jede Zelle unter dem Pinsel bekommt die Muster-Zelle ihrer Position (x mod Breite, y mod Höhe). So entstehen beliebig lange Straßen oder Flüsse. Jede Zelle wird pro Strich nur einmal gemalt (die Höhen wandern nicht).

### Im Karten-Editor (Farben)
Stempel-Menü: unter der Liste **Zeichnen** (Einmal / Freihand) und **Ebene** (Land + Statics / nur Land / nur Statics) – wird im Stempel gespeichert. „Setzen“:
* **Einmal:** der Stempel hängt an der Maus (wie bisher, „Mehrfach setzen“, „Abbrechen“). Nur Land = ohne Statics, nur Statics = Farben durchsichtig.
* **Freihand:** Werkzeug „Muster-Pinsel“ – ziehen = malen, Pinselgröße in der Leiste. Mit „Höhen an den Boden anpassen“ bekommt jede Zelle die Farbe ihrer Gruppe mit der Höhe des Bodens dort + Höhe im Muster (eine Straße folgt dem Gelände). Statics des Musters kommen in die Statics-Ebene (vorhandene Ebene-Statics an diesen Zellen werden ersetzt).
* **Live-CGI beim Zeichnen** (Häkchen, Standard an): ein kleines CGI-Fenster baut die Umgebung der Maus (etwas größer als das Muster, höchstens 96×96) im Hintergrund nach jedem Abschnitt neu – man sieht beim Zeichnen, wie die Straße im Spiel aussieht. Die Maus / Tastatur bleiben im Karten-Editor.
* **Rückgängig schrittweise** (Häkchen): ein Strich wird in Teile zu je 32 Feldern zerlegt – Strg+Z nimmt Teil für Teil zurück. **Strg+Umschalt+Z** (auch Kontextmenü „Ganzen Strich rückgängig“) nimmt den ganzen Strich zurück. Ohne Häkchen ist ein Strich ein Schritt. Gilt auch für Pinsel, Radierer, Sprühen, Höhe ±.

### In der CGI-Ansicht (echte Tiles + Statics)
Leiste Land: violetter Knopf **„✎ Muster-Pinsel“** – Menü mit den Stempeln (nach Kategorie; Stempel ohne gebaute Land-Tiles nur mit Statics) und den Optionen:
* **Freihand** (durchgehend ziehen) oder **Einmal** (Klick setzt das ganze Muster mittig).
* **Land + Statics / nur Land / nur Statics.** Land: Tile des Musters, Höhe = Gelände + Höhe im Muster (Straße bleibt auf dem Gelände, ein Flussbett wird eingegraben). Statics: Höhe über dem neuen Land; auf neu gemalten Land-Zellen werden die alten Statics ersetzt.
* **Übergänge zum Rand danach berechnen:** nach dem Strich weiche Kanten nach den Dragon-Regeln.
* **Rückgängig schrittweise (je 32 Felder)** und **Ganzen Strich rückgängig** (Strg+Umschalt+Z).

Die CGI-Ansicht zeigt jeden Abschnitt sofort, während man zieht. Danach mit „▧ Bereich → in Farbkarte“ in die Farbkarte übernehmen oder als neuen Stempel speichern.

Im Fenstertitel steht jetzt `[Stand 22.11.2026 – Pinsel 14]`.

## Muster-Pinsel: Höhen, Nachbesserung, Live während des Zeichnens, Stempel aus der 2D-Ansicht

**Warum die Straße auf den Bildern Stufen und helle Schrägen hatte:** der Pinsel hat die Höhen der Quellkarte mitgenommen (Höhe im Muster relativ zu seiner Mitte). Jetzt ist das wählbar – Standard ist **„Gelände der Karte behalten“**:

| Höhe | Karten-Editor (Farben) | CGI-Ansicht (Tiles) |
|------|------------------------|---------------------|
| **Gelände der Karte** (Standard) | Farbe der Gruppe mit der Höhe, die dort schon ist | Land-Höhe bleibt |
| **Original** | Höhe dort + Höhe im Stempel | Höhe dort + Höhe im Stempel |
| **Fest** | Farbe der Gruppe mit der festen Höhe | feste Höhe |
| **±** (alle Modi) | wird addiert (z. B. −3 für ein Flussbett) | wird addiert |

Einstellen: Stempel-Menü (Zeile „Höhe“, „fest Z“, „±“) bzw. CGI-Menü „✎ Muster-Pinsel → Höhe“. Gilt für Freihand und für „Einmal“-Stempel; wird in den Einstellungen gespeichert.

**Automatisch nachbessern** (an/aus, Standard an): nach dem Strich werden Zellen des Strichs und seines Randes, die stark von ihren 8 Nachbarn abweichen (CGI: mehr als 6 Z, Farben: mehr als 10), an den Durchschnitt angeglichen – keine Spitzen, Stufen oder Löcher am Rand. Statics darauf wandern mit. Gehört zum selben Rückgängig-Schritt. In der CGI-Ansicht danach die Übergänge zum Rand.

**Live-CGI direkt beim Zeichnen:** das Live-Fenster wird jetzt schon während des Ziehens nach jedem Abschnitt neu gebaut (nicht erst nach dem Loslassen). Leiste des Fensters: Raster, Infos (Höhe / Land-ID / ID + Höhe / ID + Höhe + Textur), **Statics** ein / aus, **Static-IDs** (ID und Höhe jedes Statics), Zoom. „Static-IDs“ gibt es auch in der großen CGI-Ansicht (neben der Infos-Auswahl).

**Stempel in der 2D-Ansicht erstellen:** „Auswahl → Stempel speichern“ fragt jetzt Name, Kategorie, **Zeichnen (Einmal / Freihand)** und Statics. Die Auswahl wird zusätzlich im Speicher gebaut – der Stempel bekommt die echten Land-Tiles mit Höhen und die Statics der Statics-Ebene. Damit taugt er auch als Pinsel in der CGI-Ansicht und zum Regeln lernen.

Im Fenstertitel steht jetzt `[Stand 22.11.2026 – Pinsel 15]`.

## Live-CGI für alle Werkzeuge des Karten-Editors

Werkzeugleiste des Karten-Editors: **„◉ Live-CGI“** (an / aus) und **„folgt Maus“**.
* **Live-CGI an:** beim Zeichnen mit jedem Werkzeug – Pinsel, Radierer, Sprühen, Höhe ±, Füllen, Linie / Rechteck / Ellipse, Einfügen, Stempel, Höhleneingang – baut ein kleines CGI-Fenster die Umgebung der Maus im Hintergrund neu (64–128 Felder, je nach Pinselgröße, + 8 Felder Rand für die Übergänge). Beim Pinsel schon während des Ziehens, sonst nach jeder Änderung. Die Karte selbst und die große CGI-Ansicht bleiben unverändert.
* **folgt Maus:** auch ohne zu zeichnen – sobald die Maus mehr als 16 Felder weiter ist, wird die neue Umgebung gebaut. So sieht man beim Überfahren der Farbkarte, was aus den Farben (Vorgaben) wird.
* Das Fenster hat Raster, Infos (Höhe / Land-ID / ID + Höhe / ID + Höhe + Textur), Statics ein / aus und Static-IDs. Fenster schließen = Live-CGI aus.

Im Fenstertitel steht jetzt `[Stand 22.11.2026 – Live 16]`.

## Höhen-Ebene (seit „Höhen 17“)

Eine Farbe der Dragon-Farbkarte trägt ihre Höhe fest in sich. Manche Farben gibt es nur in einer Höhe, z. B. Holzboden **1f** (Tiles 0406–0409) nur mit **Z 0**. Malte man bisher mit „Höhe: Gelände der Karte behalten“ einen Holzboden auf Gras mit Z 4–6, landete der Boden trotzdem auf Z 0.

Jetzt merkt sich das Studio für solche Zellen die gewünschte Höhe in einer **Höhen-Ebene**:

* Gespeichert wird sie neben der Karte in `<karte>.statics.bin`, zusammen mit den Statics.
* Muster-Pinsel (einmal oder freihand) und Stempel tragen die Höhe automatisch ein, wenn die gewählte Farbe die Höhe nicht hat (Abweichung > 1).
* Strg+Z und Strg+Y nehmen den Eintrag mit zurück.
* Der Compiler setzt die Zelle auf die gespeicherte Höhe, aber nur solange sie noch genau diese Farbe hat. Wird die Stelle später übermalt, verfällt der Eintrag von selbst.
* Das gilt für alle Wege: CGI-Bau, Aktualisieren, Live-CGI, Vorschau, Stempel speichern und Karte bauen.

## Sprung ins Live-CGI (seit „Sprung 18“)

In der Werkzeugleiste des Karten-Editors gibt es neben „◉ Live-CGI“ und „folgt Maus“ jetzt den Knopf **⌖ Sprung**.

1. Wähle **⌖ Sprung → Maustaste belegen …** und klicke danach mit der gewünschten Maustaste in die Karte. Erlaubt sind nur Tasten, die der Editor noch nicht nutzt:
   * **Maustaste 4 oder 5** (die Seitentasten)
   * **Strg + Mitteltaste** oder **Alt + Mitteltaste** (die Mitteltaste allein verschiebt die Karte)

   Bei einer belegten Taste (links, rechts, Mitte allein) kommt ein Hinweis, und die alte Belegung bleibt. Die Belegung wird gespeichert und steht danach im Knopf.
2. Klickst du mit dieser Taste auf eine Stelle der Karte, springt das Live-CGI dorthin und baut die Stelle. War Live-CGI aus, wird es eingeschaltet. **Live-Zeichnen und „folgt Maus“ bleiben dabei an** (seit „Sprung 19“).
3. Sobald du zeichnest (mit jedem Werkzeug) oder mit eingeschaltetem „folgt Maus“ die Maus weiterbewegst, zeigt das Live-CGI wieder die Stelle am Stift bzw. an der Maus.

   Möchtest du, dass die Ansicht nach dem Sprung stehen bleibt, schalte **⌖ Sprung → Sprung schaltet 'folgt Maus' aus** ein. Ab Werk ist das aus.
4. **⌖ Sprung → Belegung löschen** nimmt die Belegung wieder weg.

So kannst du Stellen, die du auf der Karte markiert hast, nacheinander anklicken und dir jeweils im CGI ansehen.

## Werkzeuge, Hilfe, Kontextmenü und Küste glätten (seit „Werkzeuge 20“)

Im Fenstertitel steht jetzt `Stand 22.11.2026 – Werkzeuge 20`.

### Werkzeug-Palette links (wie Photoshop)

Im Karten-Editor und in der CGI-Ansicht liegen die Werkzeuge jetzt als Bilder in einer schmalen Spalte links neben der Karte, in Gruppen (Malen, Formen, Höhen, Auswahl bzw. Statics, Land, Gelände, Höhlen).

* **Linksklick** wählt das Werkzeug. Der kleine Buchstabe unten rechts ist seine Taste.
* **Maus darüber** zeigt Name, Taste und eine Kurz-Hilfe.
* **Rechtsklick** öffnet die Hilfe zu diesem Werkzeug.
* **⧉** oben in der Palette öffnet sie in einem eigenen Fenster, z. B. auf dem zweiten Monitor. Fenster schließen oder **⇤** dockt sie wieder links an. Die Lage wird gemerkt und beim nächsten Start wiederhergestellt.
* Im Karten-Editor gibt es in der Palette auch den Schalter **Höhe behalten** (Berg-Bild mit Pfeil).

### Optionsleiste oben

Oben steht nur noch, was das gewählte Werkzeug hat: Bild und Name des Werkzeugs, Pinselgröße / eckig, **⛰ Höhe behalten**, bei „Auswahl“ Kopieren, Ausschneiden, Einfügen, Füllen, Löschen und → Stempel, dazu eine kurze Maus-Hilfe.

* Zoom, Raster, Höhen und Höhen-Ebene stecken im Menü **👁 Ansicht**.
* In der CGI-Ansicht enthält **👁 Ansicht** Statics, Raster, Höhen / IDs, Beschriftung, Static-IDs, 2D, Wasser durchsichtig, Probleme und Zoom. Der Knopf **Statics** bleibt zusätzlich sichtbar.
* In der zweiten CGI-Leiste stehen beim Werkzeug „Bereich“ die Befehle F K J W G M T P als Knöpfe, bei „Küste“ / „Küste glätten“ die Knöpfe Ganze Karte glätten, Nur Fehlerstellen und Fehler zeigen.
* **?** ganz rechts öffnet die Hilfe.

### Höhen-Ebene beim normalen Farb-Pinsel (Punkt 1)

**⛰ Höhe behalten** (Optionsleiste, Palette oder Kontextmenü → Höhen-Ebene):

* **An:** Pinsel, Radierer, Sprühen, Linie, Rechteck, Ellipse, Füllen und „Auswahl füllen“ nehmen die Farbe der gleichen Gruppe auf der Höhe des Bodens. Gibt es die Farbe in dieser Höhe nicht (Holzboden 1f nur Z 0 auf Gras Z 4), merkt sich die Höhen-Ebene Z 4.
* **Aus:** wie bisher, jede Farbe hat ihre eigene Höhe. Übermalt man eine Zelle mit einem Eintrag der Höhen-Ebene, wird der Eintrag entfernt. Sonst käme die alte Höhe zurück, wenn man später wieder dieselbe Farbe malt.
* Alles ist ein Rückgängig-Schritt zusammen mit den Pixeln.

### Höhen-Ebene im 2D-Editor anzeigen (Punkt 2)

* **👁 Ansicht → Höhen-Ebene zeigen:** Zellen mit Eintrag werden **türkis** (die Höhe gilt) oder **grau** (alter Eintrag, die Farbe wurde übermalt, er zählt nicht). Ab Zoom 12 steht die Höhe darin.
* **Höhen** (ab Zoom 12) schreibt Werte aus der Höhen-Ebene **gelb**.
* Die Statuszeile zeigt die Höhe unter der Maus, z. B. „Z 4 (Höhen-Ebene)“.
* **Kontextmenü → Höhen-Ebene:** Eintrag hier, in der Auswahl oder auf der ganzen Karte löschen (mit Strg+Z).

### Kontextmenü in der CGI-Ansicht (Punkt 3)

**Rechtsklick** mit Auswahl, Bereich, Löschen, Färben, Multi, Vorlage oder Höhlen-Stempel. Bei den anderen Werkzeugen nimmt der Rechtsklick weiter Land oder Item auf, dort öffnet **Umschalt+Rechtsklick** das Menü. Auch die **Menütaste** öffnet es.

* Oben: Static und Land unter der Maus mit **Item übernehmen**, **Static auswählen**, **Static löschen**, **Land-Tile + Höhe übernehmen**.
* **Werkzeug:** alle Werkzeuge mit Bild.
* **Ansicht** und **Statics zeigen** (Statics ein / aus).
* **Bereich:** alle Bereich-Befehle (füllen, Küste, Küste glätten, Wasser, glätten, heben / senken, Berg, Übergänge, kopieren / einfügen, Statics wählen / löschen, → Farb-Stempel, → Farbkarte, Regeln lernen, auswerten).
* **Küste:** Pinsel, im Bereich, ganze Karte, nur Fehlerstellen, Fehler zeigen.
* **Karte:** bauen, laden, speichern, Karte → Farbkarte, prüfen, **Diese Stelle im Karten-Editor zeigen**.
* Rückgängig, Wiederholen, ganzer Strich, Hilfe.

### Hilfe (Punkt 4)

**F1** (überall), **?** in den Leisten, „Hilfe“ im Kontextmenü oder Rechtsklick auf ein Werkzeug öffnet das Hilfe-Fenster. Es öffnet sich beim passenden Thema.

* Links stehen die Themen: Erste Karte in 10 Schritten, Aufbau des Fensters, Karten-Editor, Höhen und Höhen-Ebene, Stempel und Muster-Pinsel, Live-CGI und Sprungtaste, CGI-Werkzeuge, CGI-Kontextmenü, Bereich-Befehle, Küste und Strand, Höhlen und Berge, CGI ↔ Farbkarte, Alle Tasten und die bisherige ausführliche Anleitung.
* **Deutsch / English** oben umschaltbar, die Wahl wird gemerkt.
* **Suche** (Strg+F) filtert die Themen und markiert die Treffer gelb.
* **HTML …** speichert alles als eine HTML-Seite (zum Drucken oder Weitergeben).
* Die Inhalte liegen in `Core/StudioGuide.cs`, neue Funktionen bitte dort ergänzen.

### Küste glätten – ohne Sand-Zacken (Punkt 6)

**Ursache der Zacken:** Eine schräge oder unruhige Küste ist in der Farbkarte eine Treppe aus Land- und Wasser-Zellen. Mit dem klassischen Profil liegt der Strand auf -3, direkt daneben der Meeresgrund auf -15. Jedes Strand-Tile bekommt eine Ecke auf -15 gezogen, und der Client zeichnet eine Reihe von Sand-Zacken.

**Lösung:** Die Höhen folgen dem echten (euklidischen, leicht geglätteten) Abstand zur Küstenlinie statt den Zell-Stufen. Der Strand sinkt weich zur Wasserlinie, der Meeresgrund fällt über einige Tiles auf seine Tiefe. Die Tiefe bleibt also, sie verschiebt sich nur mit der Küste. Klippen über „Klippe ab z“ bleiben.

Getestet ohne Oberfläche (`CoastSmoother`):

* Schräge Küste: 95 Fehlerstellen vorher, 0 danach. Ein zweiter Durchlauf ändert nichts mehr.
* Unruhige Insel 2048×2048: ganze Karte in etwa 0,5 s.
* Der Pinsel ändert nichts außerhalb seines Kreises.

Bedienung:

* **Pinsel „Küste glätten“** (CGI-Palette, Gruppe Gelände): **rund**, Größe oben. Zum Überarbeiten von Hand, ein Zug ist ein Rückgängig-Schritt. Auch der klassische Pinsel **„Küste“** ist jetzt rund.
* **Bereich markieren + J** glättet den ganzen Bereich.
* **Ganze Karte glätten:** alle Küsten, oder nur der markierte Bereich, falls einer markiert ist. Läuft im Hintergrund und ist ein Rückgängig-Schritt.
* **Nur Fehlerstellen:** sucht Zacken (Abfall zum Wasser ≥ „Höhensprung ab“), einzelne Land-Spitzen und 1-Tile-Buchten und glättet nur im Umkreis darum.
* **Fehler zeigen:** markiert die Stellen rot und listet sie unter Prüfen → Probleme (Art „Küste“, Doppelklick springt hin).
* **Statics** gehen mit dem Boden mit. Wasser-Statics bleiben auf der Wasserhöhe, neues Wasser bekommt Wasser-Statics, neues Land verliert sie.

Einstellungen im Reiter **Küste / Wasser**, oben im Kasten „Küste glätten (ohne Zacken)“:

* **Abfall-Breite** (Standard 3)
* **Weichheit** (1)
* **Küstenlinie begradigen** (1 Durchgang; 0 = Land / Wasser bleibt, nur die Höhen werden weich)
* **Statics mitnehmen**
* **Fehler: Höhensprung ab** (7)
* **Fehler: Umkreis** (3)

**Beim Bauen:** In den Build-Optionen unter **6 Küste** gibt es **„Küste weich (ohne Zacken)“** mit Abfall-Breite und Weichheit. Damit macht der Compiler dasselbe für die ganze Karte. Ab Werk ist das **aus**, damit bestehende Karten gleich bleiben, bis du es in der Oberfläche geprüft hast.

## Neue Pinsel und Bearbeitung in der CGI-Ansicht (seit „Pinsel 21“)

Im Fenstertitel steht jetzt `Stand 22.11.2026 – Pinsel 21`.

Die neuen Werkzeuge findest du an mehreren Stellen:

* in der CGI-**Palette links**
* in der **Optionsleiste** (zweite Leiste) mit Knöpfen je Werkzeug
* im **Kontextmenü** (Auswahl, Bearbeiten, Ansicht-Filter, Lesezeichen, Verlauf)
* in der **Hilfe** (F1, Thema „Pinsel & Bearbeiten“)

Die Einstellungen liegen im neuen Reiter **Pinsel** (Kategorie PINSEL rechts). Ein Zug mit einem Pinsel ist ein Rückgängig-Schritt. Die Logik steht in `Core/CgiBrushes.cs`, damit sie sich weiter ausbauen lässt.

### Statics

* **Streu-Pinsel:** verteilt ein Set.
  * Einstellbar sind Dichte, Mindestabstand, „nur auf Land-Tiles“ (Knopf „Boden unter der Maus übernehmen“), nicht auf Wasser / Statics / steilen Hängen, zufällige Hues und Z +.
  * **Strg+Ziehen** entfernt die Statics des Sets.
  * **Sets:** alle Item-Dateien der Dragon-Skripte (forest, jungle, swamp, snowforest, desert …), mit mehrteiligen Objekten wie Stamm und Blättern, genau wie beim Build.
  * **Eigene Sets** entstehen aus der Auswahl: „ein Objekt“ (mehrteilig) oder „jedes Static einzeln“ (Häufigkeit = Anzahl).
* **Hue-Pinsel:** färbt alle Statics unter dem Pinsel, Strg = Hue 0.
* **Wand / Zaun:** von Ende zu Ende ziehen (West-Ost oder Nord-Süd). Pfosten an den Enden, Stockwerke, gleiche Höhe, alte Statics ersetzen.
  * Ein **Wand-Set** legst du so an: „Neues Wand-Set“, dann im Reiter Items das Stück wählen und **← West-Ost**, **← Nord-Süd**, **← Pfosten** klicken.
  * Mehrere IDs werden zufällig gemischt.

### Gelände

* **Fluss:** Bett mit Wasser-Tiles auf „Tiefe“ unter dem Startpunkt. Das Ufer steigt weich an, danach kommen die Übergänge. „Spiegel folgt dem Gelände“ ist für Bäche am Hang.
* **Weg / Straße:** Punkte klicken, daraus wird eine weiche Kurve (Catmull-Rom) mit Breite.
  * Die Höhe wird geglättet oder läuft als gleichmäßige Steigung, ein Bankett gleicht den Rand an, danach kommen die Übergänge.
  * Leere Weg-Tiles bedeuten: die Tiles aus dem Reiter Land.
  * Doppelklick, Rechtsklick oder Enter baut; Rücktaste nimmt den letzten Punkt weg; Esc bricht ab.
* **Rampe:** von unten nach oben ziehen ergibt eine gleichmäßige Steigung. Mit Strg geht sie bis „Höhe =“.
* **Plateau / Terrassen:** abflachen auf die Höhe unter dem ersten Klick (oder „Höhe =“) oder auf Stufen runden.
* **Unebenheit:** leichte Wellen ins Gelände.
* **Varianten:** mischt die Tiles derselben Farbe der Farbtabelle neu, gegen Kachel-Muster.
* **Übergänge-Pinsel:** berechnet die Dragon-Übergänge nur unter dem Pinsel.
* **Härte (%)** gilt für Höhe +/−, Glätten, Plateau und Unebenheit: Unter 100 wird der Rand weich. Höhe +/− und Glätten sind jetzt runde Pinsel.

### Auswählen und bearbeiten

* **Rahmen-Auswahl:** Mit „Auswahl“ auf freiem Boden ziehen wählt alle Statics darin (Strg = dazu).
* **Ziehen mit der Maus:** Ausgewählte Statics lassen sich direkt verschieben.
* **Alt+Klick** ist bei jedem Werkzeug eine Pipette: das Item unter der Maus, sonst Land-Tile + Höhe.
* **Lasso** (Punkte) und **Zauberstab** (gleiches Tile, gleiche Familie oder ähnliche Höhe): Umschalt = dazu, Strg = weg.
  * Solange die türkise Maske da ist, wirken **alle** Werkzeuge und Bereich-Befehle nur darin. Esc hebt sie auf.
  * Technisch: `MapData.EditMask` filtert jede Änderung, Rückgängig ist nicht eingeschränkt.
* **Bereich / Lasso:**
  * **R** dreht um 90°, **X / Y** spiegelt (Land + Statics).
  * **E** öffnet Suchen & Ersetzen.
  * **D** setzt die Statics auf den Boden.
* **Auswahl:** **R / X** dreht bzw. spiegelt die Statics um ihre Mitte, **D** setzt sie auf den Boden.
* **Suchen & Ersetzen:**
  * Statics-IDs: gleich viele IDs werden 1:1 ersetzt, sonst zufällig; ein leeres Ziel löscht.
  * Dazu „nur mit Hue“ und „neue Hue“.
  * Land-Tiles lassen sich ebenso ersetzen.
  * Wirkt im Bereich / Lasso oder auf der ganzen Karte.
* **Messen:** Abstand, Schritte, Δz und Steigung (z pro Tile) als Linie mit Text.

### Komfort

* **Ansicht-Filter:** Bäume / Pflanzen, Wände / Türen / Fenster, Dächer, Wasser, Böden und Sonstige lassen sich ausblenden, über TileData-Flags und Namen. Ausgeblendetes ist nicht anklickbar.
* **Lesezeichen:** Stellen merken und hinspringen, in der CGI-Ansicht oder im Karten-Editor. Erreichbar über das Kontextmenü in beiden Ansichten und den Reiter Pinsel. Gespeichert in den Einstellungen.
* **Verlauf:** ein Fenster mit allen Schritten der CGI-Karte und ihren Namen. Ein Klick auf einen Schritt geht dorthin zurück oder wieder vor.
* **Palette:** Angedockt nutzt sie automatisch 3 oder 4 Spalten, wenn 2 nicht in die Höhe passen.

### Hinweise

* Beim Drehen eines **nicht quadratischen** Bereichs bleiben Reste am alten Platz. Am besten quadratisch markieren.
* Die **Bilder der Statics drehen nicht mit**, eine Südwand bleibt eine Südwand.
* Ohne Oberfläche getestet (`CgiBrushes`):
  * Drehen 4× ergibt wieder das Original.
  * Fluss: Wasser auf Startpunkt − Tiefe, das Ufer steigt weich an.
  * Rampe 0 → 30 gleichmäßig, Terrassen in Stufen.
  * Unebenheit bleibt im Rahmen ± Stärke.
  * Wand mit Pfosten und Stockwerken.
  * Ersetzen und „auf Boden“ arbeiten richtig.
  * Zauberstab und Lasso liefern die richtigen Felder, die Maske sperrt Änderungen außerhalb.
  * Die Einstellungen überstehen Speichern und Laden (JSON).

## Formen, natürlicher Lauf, Brücke, Keller, unter der Karte, Dungeon-Generator (seit „Bauen 22“)

Im Fenstertitel steht jetzt `Stand 22.11.2026 – Bauen 22`. Alles ist in Palette, Optionsleiste, Kontextmenü und Hilfe eingetragen (F1: „Formen …“ und „Bauen …“). Die Logik liegt in `Core/Builders.cs`.

### Karten-Editor (Farbkarte)

* **Halbkreis:** von der Mitte der geraden Seite zur Rundung ziehen.
* **Dreieck:** von der Mitte der Grundseite zur Spitze ziehen.
* Beide Formen sind **gefüllt** oder nur Rand (Schalter oben, Dicke = Pinselgröße).
* **Neigungs-Linie:** Die Höhe läuft von der Höhe am Start zur Höhe am Ende. Jede Zelle bekommt die Farbe der Gruppe von Farbe 1 in der passenden Höhe, fehlt sie, merkt sich die Höhen-Ebene die Höhe. Für Rampen sowie Straßen und Flüsse am Hang.
* **Natürlicher Lauf:** von der Quelle zur Mündung ziehen, geschlängelt und zum Ende breiter.
  * Gemalt wird mit Farbe 1 und Pinselgröße, oder mit dem Muster-Stempel (Land + Statics), Schalter oben.
  * „Schlängeln …“ stellt Stärke, Bögen und Breite ein.
  * Die Vorschau zeigt genau den Lauf, der gemalt wird.
* **Dungeon:** Rechteck aufziehen ergibt Räume und Gänge. Farbe 1 = Boden, Farbe 2 = Wand / Fels, optional den ganzen Rest mit Fels füllen.

### CGI-Ansicht

* **Brücke:** von Ufer zu Ufer ziehen (West-Ost oder Nord-Süd).
  * Bretter, Geländer an den Seiten, Pfosten an den Enden, Bogen in der Mitte.
  * Brücken-Set: „Neu …“, dann die Stücke im Reiter Items wählen und **← Brett W-O / N-S**, **← Geländer …**, **← Pfosten** klicken.
* **Keller:** Rechteck aufziehen.
  * Das Land wird **NoDraw (0002)** auf Boden − Tiefe (20), damit zeichnet der Client darunter.
  * Wände am Rand (Wand-Set), innen der Kellerboden (Statics).
  * Treppe in 5er-Stufen hinunter nach Nord, Ost, Süd oder West.
  * Optional der Hausboden oben, außer über der Treppe.
  * Treppen-Set: **← ab Nord / Ost / Süd / West** mit dem gewählten Item.
* **Unter der Karte bauen:** Schalter in Palette, Leiste, Ansicht und Reiter.
  * Statics unter dem Boden werden über dem Land gezeigt.
  * Ein **violettes Banner** zeigt, dass du unter der Karte baust, mit der Bau-Ebene.
  * Static setzen und Wand bauen setzen auf Boden + Bau-Ebene (−20).
* **Dungeon-Generator:** Rechteck aufziehen (mindestens 10×10). Das Vorgehen kommt aus den Roguelike-Generatoren:
  * Räume liegen zufällig ohne Überschneidung.
  * Sie sind über einen **minimalen Spannbaum** verbunden, dazu kommen „Schleifen“ % Extrawege.
  * Gänge sind L-förmig, „höhlige“ Ränder sind einstellbar.
  * Drei Arten:
    * **Höhle** (im Berg: Höhlen-Boden-Tiles, Wände = Fels).
    * **Gebaut** (Boden-Statics + Wandstücke je Richtung, Ecken = Pfosten).
    * **Unter der Karte** (wie ein Keller).
  * Die benutzte Zufalls-Zahl steht in der Statuszeile. Mit ihr lässt sich derselbe Dungeon noch einmal bauen.
* **Fluss-Lauf:** von der Quelle zur Mündung ziehen, ein natürlich geschlängelter Fluss mit den Fluss-Einstellungen.

### Getestet ohne Oberfläche

* Dungeon: alle Böden sind zusammenhängend erreichbar (276 von 276).
* Unter der Karte: NoDraw auf −20, Wände nach Richtung.
* Keller-Treppe: z 0 / −5 / −10 / −15 nach Norden.
* Brücke: Bogen −5 → −1 → −5, Geländer und Pfosten.
* Lauf: endet genau auf A und B.

### Noch nicht ausgeliefert

* Fertige **Wand-, Brücken- und Treppen-Sets** fehlen, weil die richtigen Item-IDs je nach Client verschieden sind. Du legst sie einmal mit „← …“ aus dem Item-Katalog an, sie werden gespeichert.

## Dungeons richtig: Stil lernen, Analyse-Log, Bergwall (seit „Dungeon 23“)

Im Fenstertitel steht jetzt `Stand 22.11.2026 – Dungeon 23`.

Der erste Dungeon-Generator hat „Höhle“ als Standard benutzt und Fels-Land hochgezogen. Das ist kein UO-Dungeon. Dieses Fels-Labyrinth bleibt aber als eigenes Werkzeug **Bergwall** erhalten (Palette, Gruppe Bauen).

**So sind UO-Dungeons gebaut** (aus deinen Screenshots ausgelesen):

* Der Boden ist Land mit einer Dungeon-Textur, z. B. auf z 22.
* Außen liegt schwarzes Void-Land (z. B. 0244) in beliebiger Höhe.
* Die Wände sind **Statics** (z. B. 0241 / 0243) auf der Grenze Boden ↔ Leere, in Bodenhöhe.
* Dazu kommt Deko (10ef / 10f0 Knochen und Schutt, Spinnweben, Fackeln mit Höhe +15).

### Dungeon-Stil lernen und Analyse-Log

1. Eine Karte mit Dungeons in der CGI-Ansicht laden (z. B. map0 bei x > 5119).
2. Einen Dungeon mit **Bereich** markieren, mit etwas schwarzem Rand.
3. Kontextmenü → Bereich → **„Dungeon-Stil aus dem Bereich lernen …“** (oder Reiter Pinsel → Dungeon), Name vergeben (z. B. Deceit).

Gelernt wird:

* **Boden-Land** (Textur) und **Void-Land** (die häufigste Kachel am Rand des Bereichs).
* Für jede Lage einer Zelle der Wand-Stapel:
  * ob die Zelle Boden oder Leere ist,
  * welche Nachbarn N / O / S / W Boden sind,
  * bei Außenecken, welche schrägen Nachbarn Boden sind.
  * Dazu die **Wand-Stapel** dort (id + Höhe über dem Boden), als Stichprobe von bis zu 24 je Lage, und wie oft die Lage Statics hat.
* **Boden-Statics** und **Deko** mit ihrer Häufigkeit.

**„Nur analysieren (Log)“** und das Lernen schreiben `dungeon_analyse_<Name>.txt` in den Log-Ordner und in die Zwischenablage. Der Log enthält:

* Boden-Land mit Textur-ID und die Boden-Höhen,
* jedes Static mit Höhe über dem Boden und Rolle (Wand / Boden / Deko), TileData-Flags und Anzahl,
* die Wand-Regeln (Lage → häufigste Stapel),
* einen ASCII-Plan (`#` Wand, `.` Boden, `d` Deko).

Den Log kannst du mir schicken, dann verfeinere ich die Regeln weiter.

### Dungeon bauen

* Werkzeug **Dungeon**, Rechteck aufziehen.
* Räume und Gänge entstehen wie bisher (minimaler Spannbaum + Schleifen), jetzt standardmäßig mit **geraden Wänden**.
* Mit gelerntem Stil:
  * Boden-Textur auf Bodenhöhe, Void-Land außen (Schalter „Leere mit Void füllen“).
  * In jede Lage kommt ein Wand-Stapel aus dem Original, in der Häufigkeit des Originals.
  * Fehlt eine Lage im Original, nimmt er die ähnlichste.
  * Deko kommt in der Häufigkeit des Originals dazu.
* Ohne Stil: Wand-Set mit Pfosten an den Ecken.
* „Unter der Karte“ baut den Dungeon unter den Boden (NoDraw-Land).

### Test ohne Oberfläche

* Test-Dungeon gebaut (Boden 0500 auf z 22, Void 0244, Wandstücke je Richtung, Eckpfosten, 5 % Deko).
* Daraus den Stil gelernt, dann einen **anderen** Dungeon damit gebaut.
* Ergebnis: **390 von 390** Wandstücken an der richtigen Stelle, Void und Boden richtig, Deko in gleicher Häufigkeit.

## Dungeon nach echter map0-Analyse (seit „Dungeon 24“)

Im Fenstertitel steht jetzt `Stand 22.11.2026 – Dungeon 24`. Grundlage war dein Log von map0 (6035, 25, 91×78). Daraus gelesen:

* **Boden:** Höhlen-Textur 0245–0249 auf z 0 und z 22, also zwei Ebenen. Die Rampen dazwischen sind aus 07a3 „stone“ und 07a4–07a7 „stone stairs“.
* **UO-Wand-Regel:**
  * Die Westwand 0242 steht auf der Leere links vom Boden (113 von 118).
  * Die Nordwand 0241 steht auf der Leere oberhalb (103 von 116).
  * Die Südwand 0241 und die Ostwand 0242 stehen auf dem **letzten Bodenfeld innen** (114 von 124 bzw. 110 von 122).
  * Leere südlich bzw. östlich hat fast nie ein Static.
* **Innenwände:** Wände zwischen Räumen stehen auf Boden-Land (im Plan `#....#....#`).
* **Grundriss:** Räume dicht an dicht mit Durchgängen von 2–3 Feldern.

### Neu

* **Innenwände** werden gelernt: Wand-Statics auf Boden-Land mit Boden ringsum, nach Richtung W-O, N-S oder Ecke.
* **Rollen** der Statics:
  * **Wand**
  * **Wand-Deko** (Fackeln, Bilder, Teppiche): wird an Wänden gelernt und dort wieder angebracht.
  * **Deko** (lose: Schutt, Blut, Knochen, Spinnweben): nur auf freiem Boden.
  * **Einrichtung** (Tische, Stühle, Theken, Steine, Treppen): wird nicht mehr zufällig verteilt, erscheint aber im Log.
  * **Boden**
* **Grundriss „Gitter“** (Standard, wie Deceit):
  * Der Bereich wird immer wieder geteilt (BSP), bis die Räume klein genug sind.
  * Zwischen zwei Hälften liegt eine Wand-Zeile auf Boden-Land (Wand-Dicke 1) mit einer Tür, manchmal einer zweiten (Schleifen %).
  * Wand-Dicke 2 = eigene Wände je Raum.
  * „Räume + Gänge“ gibt es weiter, der Bergwall nutzt immer diesen Grundriss.
* Den Stil bitte **neu lernen**, damit Innenwände und Wand-Deko mit drin sind.

### Test ohne Oberfläche

* Gitter: alle Räume erreichbar (1650 von 1650 Feldern).
* Innenwände bekommen ihre Stücke (313 von 322, der Rest liegt am Rand und nimmt die Außenwand-Regel).
* Fackeln nur an Wänden, Deko nur auf freiem Boden, Void außen, Boden-Textur auf z 22.

### Noch offen

* Mehrere **Ebenen** (z 0 / z 22) mit Treppen und Rampen aus „stone“ / „stone stairs“.
* **Einrichtung je Raum**, z. B. ein Raum mit Tischen und Stühlen wie im Original.

## Dungeon-Werkstatt (seit „Werkstatt 25“)

Im Fenstertitel steht jetzt `Stand 22.11.2026 – Werkstatt 25`. Umgesetzt nach deinen Vorgaben:

* **Namen:**
  * Der Fels-Raster aus Bild 1 heißt jetzt **Berg-Dungeon**.
  * Das Fels-Labyrinth aus Bild 2 bleibt **Bergwall**.
  * Beide sind in der Werkstatt als Art wählbar.
* **Platz markieren:** mit „Bereich“.
  * Die CGI-Ansicht zoomt jetzt bis 1:32 heraus.
  * Unter 1:4 zeigt sie eine schnelle Farb-Übersicht (Land- bzw. Static-Farbe je Tile), damit man große Plätze markieren kann.
* **Öffnen:** Palette → **Dungeon-Werkstatt** oder **Keller (Werkstatt)**, oder Kontextmenü → Bereich → „Dungeon-Werkstatt für diesen Platz …“.

### Das Fenster

* **Arbeitskopie:** Alles geschieht erst in einer Kopie des Platzes (plus Rand). **In die Karte übernehmen** schreibt es als *einen* Schritt zurück, in der CGI-Ansicht geht Strg+Z.
* **Zwei CGI-Ansichten:**
  * **Oben** die Karte, wie sie ist.
  * **Unten** die gewählte Etage: Statics unter dem Boden werden gezeigt, alles darüber ist ausgeblendet.
  * In beiden lässt sich mit der Leiste weiterbauen: Auswahl, Bereich, Static setzen, Löschen, Wand / Zaun, **Loch (NoDraw)**, Land setzen, Messen, Zoom, 2D.
* **Art:** Klassischer Dungeon, Keller, Berg-Dungeon, Bergwall.
* **Etage:**
  * Die Kartenhöhe des Platzes wird ermittelt (häufigste Höhe, z. B. 0 bei Städten).
  * Der Regler geht in 20er-Etagen (… −40, −20, 0, +20 …), dazu gibt es „z genau“.
* **Leere außen:** NoDraw 0002, Schwarz 0244 oder „Wählen …“ aus dem Land-Katalog (z. B. Schwarz mit Sternen), mit Bild.
* **Klassischer Dungeon:**
  * Der Platz wird erst **geleert**: alle Statics weg (auch Wasser), das Land wird zur Leere **auf seiner eigenen Höhe**, also keine Löcher in die Tiefe.
  * Dann wird gebaut: Boden-Textur, Wand-Statics und Deko im Stil.
  * Eingebaut ist die Vorgabe **„Klassisch (map0-Log)“** aus deinem Log (Höhlenboden 0245–0249, Wände 0241/0242/0243 nach der UO-Regel, Schutt und Blut). Gelernte Stile kommen dazu.
  * Liegt die Etage **unter der Karte**, bleibt das Land oben NoDraw auf Kartenhöhe, und der Dungeon liegt darunter nur aus Statics (Höhlenboden-Statics 053d / 053e wie im Log).
* **Keller:**
  * Er besteht nur aus Statics unter der Karte, auf Kartenhöhe minus Etage.
  * Der Kellerboden, Wände (Wand-Set) und Treppe (Treppen-Set) werden gebaut.
  * „Land / Loch“: Standard ist **nur über der Treppe ein Loch** auf Kartenhöhe (ca. 3 Felder). Alternativ die ganze Fläche, oder das Land bleibt und du setzt die Löcher selbst mit dem Werkzeug **Loch (NoDraw)**, einzeln oder in einem Zug.
* **2D-Plan:** Der Grundriss lässt sich ansehen und **nachzeichnen** (links Boden, rechts Fels, Umschalt Innenwand, Strg Gang, Pinsel 1–3), dann **Aus Plan bauen**.
* **Skript / Stil:** Der Stil als JSON zum Ansehen und Ändern, mit **Skript übernehmen** oder **Als neuen Stil speichern**.
* **Scannen:**
  * Einen Dungeon der Karte im Studio markieren.
  * **Bereich scannen + Stil lernen** (Log im Reiter Log und als Datei), oder **1:1 hierher kopieren** (der Boden der Quelle landet auf der gewählten Etage).
* **Bearbeiten:**
  * **Rückgängig / Wiederholen** (auch Strg+Z / Strg+Y), **Alles zurück**.
  * **Verschieben** N / S / W / O, **Höhe** ±1, ±5, ± Etage.
  * **Schnell löschen:** Statics, Land / Textur oder beides, für den Platz oder einen kleineren markierten Bereich.

### Test ohne Oberfläche

Der Kern wurde genau so getestet, wie das Fenster ihn benutzt:

* Leeren entfernt das Wasser, gebaut werden 23 Räume mit 651 Wand-Statics.
* Verschieben behält alle Statics, Höhe −20 setzt Boden und Wände auf −20, zweimal Rückgängig stellt alles wieder her.
* In die Karte übernehmen ist ein Schritt, Rückgängig in der Karte stellt den alten Stand wieder her.
* Unter der Karte bleibt das Land auf z 0, die Boden-Statics liegen auf −20.
* Keller: 8 Lochfelder auf Kartenhöhe über der Treppe, Kellerboden auf −20.
* Ein Schemabild des erzeugten Dungeons liegt bei der Übergabe.

### Als Nächstes

Brücken, Geländer und Treppen mit Teilen, die automatisch aus TileData (Namen, Flags) gesucht und mit art.mul-Bildern zur Auswahl gezeigt werden.

## Brücken, Katalog, Radierer, Treppe, fremde Karte (seit „Werkstatt 26“)

### Fluss-Lauf mit Wasser und Breite
* Die Mitte des Flusses bleibt jetzt immer Wasser, auch nach den Dragon-Übergängen. Vorher hat ein schmaler Fluss nur Ufer-Tiles bekommen und sah aus wie ein Erdweg.
* „Fluss: Breite / Schlängeln …“ (Optionsleiste): **Breite am Anfang** und **Breite am Ende** in Tiles (0 = Pinselgröße). Die Vorschau beim Ziehen zeigt die Breite.
* „Wasser …“: Tiefe, Ufer, Übergänge und neu **Wasser-Statics dazu** (1797–179c auf der Wasserfläche).
* Der Fluss-Pinsel behält die Mitte ebenfalls als Wasser.

### Brücken aus Statics
* Werkzeug **Brücke**: von Ufer zu Ufer ziehen. Beim Ziehen sieht man die echten Teile.
* Ohne Plan und ohne Set sucht das Studio die Teile selbst in der TileData: Bretter (Surface, Namen wie bridge / plank / board), Geländer (railing / fence), Pfosten, Pfeiler, Laterne, Treppe. Ob ein Geländer West-Ost oder Nord-Süd läuft, erkennt es am Bild.
* Die Brücke hat Bretter, Geländer an beiden Seiten, Pfosten alle 2 Tiles, Laternen, **Pfeiler bis zum Wasser** und **Treppen an den Enden**, wenn sie höher liegt als das Ufer.
* Reiter Pinsel → Brücke: **Plan** wählen (aus dem Designer) oder ein Set.

### Brücken-Designer (eigenes Fenster)
* Palette → **Brücken-Designer** oder Reiter Pinsel → Brücke → „Brücken-Designer öffnen …“.
* **Testfeld** mit zwei Ufern und Wasser in CGI-Ansicht. „Muster“ zeigt die Brücke einmal flach zum Bearbeiten, „Vorschau lang“ mit Bogen, Pfeilern und Treppen, „W-O / N-S“ dreht.
* **Teile:** Knöpfe Bretter / Geländer W-O / Geländer N-S / Pfosten / Pfeiler / Lampe / Treppe N-O-S-W zeigen unten im Katalog alle passenden Teile der TileData als Bild. Doppelklick ordnet zu.
* **Von Hand:** im Muster mit Katalog, Static setzen, Löschen, Radierer, Multi setzen bauen, dann „Muster übernehmen“. „Andere Richtung ableiten“ macht die Nord-Süd-Version.
* **Aus der Karte:** eine echte Brücke in der CGI-Ansicht mit „Bereich“ markieren → „Brücke aus der Karte“. **Aus einer Multi:** „Multi laden …“, dann im Katalog doppelklicken.
* Anfang / Ende im Plan: diese Tiles werden einmal gebaut, die Mitte wird bei langen Brücken wiederholt.
* **Speichern nach Kategorie** (Holz, Stein, Dungeon …). „✔ Im Studio benutzen“ gibt den Plan dem Brücken-Werkzeug.

### Katalog (Statics, Land / Textur, Multis)
* In Werkstatt und Brücken-Designer: Bilder aller Teile, **Suche** nach Name oder Hex-ID, Größe der Bilder wählbar.
* **Kategorien:** eingebaute (◆ Wände, Böden, Treppen, Brücke, Geländer, Pfeiler, Türen, Dach, Pflanzen, Wasser, Licht, Dungeon-Deko, Möbel; beim Land Wasser, Höhle, Fels, Gras, Sand, Erde, Schnee, Lava, Leere) und **eigene**: „+ Kategorie“, Rechtsklick → „In Kategorie …“, „Alle gezeigten in Kategorie …“, „Aus dieser Kategorie entfernen“. Ab Werk gibt es „Dungeon (map0)“ und beim Land „Dungeon / Höhle“.
* Gespeichert in `katalog_kategorien.json` bei den Einstellungen.

### Radierer und Treppe (CGI-Ansicht und Werkstatt)
* **Radierer:** runder Pinsel, löscht alle Statics darunter. Strg = Land zur Leere. Größe wie jeder Pinsel. Einstellungen: nur sichtbare, Land mit, Leere-Tile.
* **Treppe:** Klick setzt Stufen nach unten in die Richtung (R dreht), je Stufe 5 Z, bis unten gefüllt. Stufen und Breite unter „Richtung / Stufen …“. Vorschau beim Zeigen. „Treppe aus TileData“ legt ein Treppen-Set aus der TileData an (Richtung bitte prüfen).

### Werkstatt: neue Möglichkeiten (auch im Keller)
* Werkzeugleiste: Radierer, Treppe, Multi setzen, Höhe + / −, Rampe, Glätten, **Pinselgröße** 1–17 (auch für Loch / NoDraw), **Gitter** und **Statics** ein / aus, **Katalog** unten ein / aus.
* Klick im Katalog wählt das Teil und das Werkzeug (Static setzen, Land setzen, Multi setzen).
* **4b Vorlagen und fremde Karten:** „Fremde Karte öffnen …“ lädt eine andere map#.mul / .uop mit Statics in ein eigenes CGI-Fenster. Dort zum Dungeon springen (X / Y), mit „Bereich“ markieren und „✔ Bereich in die Werkstatt“. Die fremde Karte wird nie verändert.
* „Platz als Vorlage speichern …“ (Kategorie + Name) und „Vorlage laden“ setzt sie auf der gewählten Etage wieder ein.
* **Hilfe-Knöpfe:** Generieren, 2D-Plan, 3D bauen (auch im Hilfe-Fenster unter „Bauen“).

## Werkzeug-Einstellungen, Seitenleiste, Hue, Lauf-Arten (seit „Werkstatt 27“)

### Natürlicher Lauf im Karten-Editor: was er malt
* Oben bei „Natürlicher Lauf“ gibt es jetzt **Art**: Fluss, Bach, Berg-Kamm, Weg, Eigene, Stempel.
* Fluss / Berg / Weg suchen ihre Farben beim ersten Mal selbst in der Farbtabelle (Wasser + Sand-Ufer, Fels oben + Fels unten, Weg / Erde).
* **„Lauf-Arten …“**: eigene Arten anlegen, kopieren, löschen. Je Art: **Kern-Farbe** (Mitte), **Rand-Farbe** + Breite, **Außen-Farbe** + Breite, Breite am Anfang / Ende, Schlängeln, Bögen. Farbe links als Farbe 1 wählen, dann „Farbe 1 → Kern / Rand / Außen“.
* Art „Stempel“ malt den Lauf mit dem gewählten Muster-Stempel (Land + Statics).

### CGI-Ansicht: Seitenleiste und Palette
* **⧉ Seite lösen** (oben rechts): die ganze Seitenleiste (Items-Katalog, Multis, Land, Pinsel …) als eigenes Fenster – frei zur Seite schieben. Oben im Fenster **↶ Rückgängig / ↷ Wiederholen** (auch Strg+Z / Strg+Y). Schließen = wieder andocken.
* **◨ Seite** oder **F8**: Seitenleiste ein- / ausblenden. **◧ Werkzeuge** oder **F7**: Werkzeug-Palette links ein- / ausblenden (auch im Karten-Editor).

### Jedes Werkzeug: Werte direkt oben in der Leiste
* Die wichtigsten Werte stehen sofort in der Optionsleiste, **⚙** öffnet alle Einstellungen.
* **Küste:** Wasserspiegel, Meeresgrund, Wasser-Breite, höchstes Land, Grund setzen. **Küste glätten:** dazu Abfall-Breite, Weichheit, Statics mitnehmen.
* **Fluss / Fluss-Lauf:** Tiefe, Ufer-Breite, Ufer-Steigung, **Grund tiefer** (wie an der Meeresküste: Grund unter den Wasser-Statics, „Grund-Tiles“ z. B. Sand), Wasser-Statics; beim Lauf Breite am Anfang / Ende und Schlängeln.
* **Weg:** **Weg-Vorlage** (gespeicherte Wege mit allen Einstellungen, „Jetzige Einstellungen als Vorlage speichern“, „Vorlagen bearbeiten“) und **womit** gebaut wird: Weg-Tiles oder ein **Stempel** (auch aus der Karte gelernt: Bereich → „→ Stempel (P)“) – der Stempel läuft dann entlang der Kurve.
* **Unebenheit:** **Muster** (weiche Wellen, Hügel, Mulden, Grate, Rillen mit Richtung, Stufen, grob), Stärke, Größe, Feinheit – mit kleinem Vorschau-Bild.
* **Varianten:** eigene **Muster** aus Land-Tiles („Neu aus Bereich“ nimmt die Tiles eines markierten Bodens mit ihrer Häufigkeit, „Muster bearbeiten“: Tiles, nur auf bestimmten Tiles, Chance) oder wie bisher die Familie der Farbtabelle.
* **Wand:** Set wählen, **Sets bearbeiten** (Teile West-Ost / Nord-Süd / Pfosten, auch „Aus Auswahl“ mit Richtungs-Erkennung), **Dicke** (mehrere Reihen), Stockwerke, **Punkt zu Punkt** (Punkte klicken, Ecken als L, Doppelklick / Enter = fertig).
* **Färben / Hue-Pinsel:** Hue-Nummer mit **Farbfeld und Name**, **🎨 Wählen …** (alle Hues mit Farbverlauf, Suche nach Nummer oder Name), **☆ merken** und **★ Favoriten**.
* **Radierer:** Statics / Land, nur sichtbare, **nur bestimmte IDs** – „Auswahl merken“ übernimmt die IDs der gewählten Statics, „alle“ hebt das auf. Beim Werkzeug Löschen führt ein Knopf zum Radierer mit Pinselgröße.
* **Multi setzen:** „✖ Multi-Auswahl löschen“. Im Reiter Multis erscheint das Bild sofort (auch beim Tippen der ID), darunter ein **Katalog aller Multis** mit Suche.
* **Berg, Brücke, Treppe, Rampe, Plateau, Streuen:** die wichtigsten Werte ebenso oben.

## Treppenhaus, Brücken-Regler, Optionen-Fenster und mehr (seit „Werkstatt 28“)

### Treppen wie im Original
* Werkzeug **Treppe**: Klick = Fuß. Je Lauf **4 Stufen zu 5 Z = 20 Z = eine Etage**, danach **ein flaches Feld (Absatz)**, dann der nächste Lauf. Alles bis unten gefüllt.
* Einstellbar (Leiste oben): Richtung hinauf (R dreht), **Etagen**, Stufen je Lauf, Breite, **Wende** (gerade, rechts herum, links herum = Wendeltreppe, zurück = U), Absatz oben, **nach unten bauen** (vom Haus in den Keller). Vorschau am Mauszeiger.
* **„Treppe aus Auswahl lernen“**: eine von Hand gebaute Treppe auswählen – Stufe je Richtung, Füll-Block und Absatz werden erkannt und als Treppen-Set gespeichert. Ganze Treppen-Muster als Werkstatt-Vorlage speichern.

### Brücken
* Brücken-Designer: **Regler für Länge, Breite und Bogen**, Testfeld größer (bis 90 Tiles lang).
* **„Bogen aus Stufen“**: die Brücke steigt in Stufen (je 5 Z) an, ist oben flach und geht wieder hinunter (Treppen-Stufen im Plan nötig). Auch in der CGI-Leiste beim Werkzeug Brücke.
* „🖼 Pläne mit Bild …“ zeigt alle gespeicherten Pläne als Bilder.

### Werkzeug-Optionen als eigenes Fenster
* In der Optionsleiste **⧉**: alle Werte des Werkzeugs in ein eigenes Fenster (z. B. auf einen anderen Monitor). Oben die Knöpfe und Felder, darunter **Tabs** mit allen Einstellungen und **„Skript (JSON)“** zum Anpassen, Übernehmen, Kopieren, Speichern und Laden. **⇤** holt sie zurück in die Leiste.
* Das Fenster und die gelöste Seitenleiste merken sich ihre Position und gehen beim nächsten Start wieder dort auf.

### Weitere Verbesserungen
* **Drehen um 90°** (Bereich / Auswahl) tauscht gerichtete Teile (Wände, Zäune, Geländer) gegen die Teile der anderen Richtung.
* **Wand-Ecken:** Wand-Set mit „Ecke“ – an L- und T-Ecken kommt das Eckstück („Item → Ecke“ im Set-Editor).
* **Streuen:** weitere Sets dazumischen („+ Set mischen“) und **Rand ausdünnen** für natürliche Waldränder.
* **Kartenübersicht:** Lesezeichen (gold, mit Namen) und Fehlerstellen (rot) werden angezeigt.
* **Dungeon mit Etagen:** Werkstatt → Grundriss → „Etagen“ – mehrere Ebenen untereinander, verbunden mit Treppen (Treppen-Set nötig).
* **Einrichtung lernen:** beim Stil-Lernen werden Tische, Stühle, Kisten usw. erkannt und beim Bauen an die Wände gestellt, so oft wie im Original.
* **Weiche Küste** beim Bauen aus der Farbkarte ist jetzt ab Werk an.
* **Vorlagen mit Bild:** Werkstatt → „🖼 Vorlagen mit Bild …“.
* **Französisch** ist jetzt vollständig (Menü Sprache / Language / Langue).

## Test-Assistent (seit „Werkstatt 29“)

Menü **Hilfe → 🧪 Test-Assistent** oder Knopf **„🧪 Test“** oben rechts in der CGI-Ansicht. Damit kannst du alles nacheinander prüfen und dem Entwickler genaue Daten schicken.

* **⚙ Automatisch prüfen (alle):** 17 Tests bauen auf kleinen Karten im Speicher – mit deinen Client-Dateien – Brücke, Bogen aus Stufen, Treppenhaus (alle Wenden), Treppe lernen, Drehen mit Teile-Tausch, Wand mit Ecken, Fluss, Küste glätten, Unebenheit, Dungeon mit 2 Etagen, Vorlagen, Katalog, Einstellungen. Jeder Wert steht im Protokoll (welche Teile gefunden wurden, welche Richtung erkannt wurde …). Deine Karte bleibt unverändert.
* **Prüfliste:** 21 Schritte. Je Schritt „▶ Vorbereiten“ (wählt das Werkzeug / öffnet das Fenster), dann die Aufgabe ausführen, „📷 Aufnehmen“ (Bildschirmfoto aller Studio-Fenster, Werkzeug mit Einstellungen, jedes gesetzte Static und Land-Tile mit ID, Name, Höhe und Richtung), dann **✔ Passt / ✖ Falsch / ? Unklar** mit Kommentar.
* Fehler des Studios werden mitgeschrieben, solange der Test-Assistent offen ist.
* **💾 Bericht speichern:** eine ZIP in „Dokumente“ (`DragonMapStudio_Testbericht_….zip`) – diese Datei schicken.

### Nach dem ersten Testbericht (seit „Werkstatt 30“)
* Die automatischen Tests machen jetzt **Bilder** mit deiner Client-Grafik (Brücke W-O / N-S, Bogen aus Stufen, Treppenhaus in allen Wenden, Treppen je Richtung, Drehen vorher / nachher, Wand, Fluss, Küste vorher / nachher, Dungeon und Treppe zwischen den Etagen). Sie liegen als `autoNN_….png` im Bericht.
* Neuer Knopf **„⚙💾 Automatisch + Bericht“**: alle Tests mit Bildern und gleich die ZIP.
* Brücken nehmen jetzt nur die Bretter der richtigen Richtung (W-O oder N-S), im Designer gibt es dafür „Bretter N-S“.
* Wand: Knopf **„Wand-Set aus TileData“** (z. B. stone → 0025 / 0026 mit Pfosten), im Set-Editor „Teile aus TileData vorschlagen“. Der Test warnt, wenn ein Wand-Set kaputt ist (z. B. 0001 = nodraw).
* Treppe aus TileData nimmt nur Stufen mit 5 Z Höhe. Katalog-Kategorien ohne „Missing_Name“ und nodraw, „Licht“ ohne Fenster.

### Treppen richtig geneigt (seit „Werkstatt 31“)
* Die Stufen aus der TileData werden jetzt **nach ihrer Neigung im Bild** den Richtungen zugeordnet (vorher nur der Reihe nach geraten – daher die falschen Neigungen).
* Beim Werkzeug Treppe: Knopf **„Richtungen aus Bild“** ordnet die Stufen des gewählten Treppen-Sets neu (oder legt ohne Set eines aus der TileData an) und zeigt die Messwerte.
* Der Test-Assistent schreibt die Messwerte jeder Stufe ins Protokoll, warnt bei falsch zugeordneten Sets und macht größere Einzelbilder je Richtung und je Wende.

