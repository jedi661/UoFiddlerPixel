﻿// /***************************************************************************
//  *
//  * Dragon Map Studio – tab "CGI-Ansicht": client view of the built map, static / multi editing
//  *
//  * "THE BEER-WINE-WARE LICENSE"
//  * As long as you retain this notice you can do whatever you want with
//  * this stuff. If we meet some day, and you think this stuff is worth it,
//  * you can buy me a beer and Wine in return.
//  *
//  ***************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using UoFiddler.Plugin.ConverterMultiTextPlugin.DragonMapStudio.Controls;
using UoFiddler.Plugin.ConverterMultiTextPlugin.DragonMapStudio.Core;
using UoFiddler.Plugin.ConverterMultiTextPlugin.DragonMapStudio.Dialogs;

namespace UoFiddler.Plugin.ConverterMultiTextPlugin.DragonMapStudio
{
    public partial class DragonMapStudioForm
    {
        private MapData _cgiMap;
        private bool _cgiFromEditor;
        private readonly Dictionary<ToolStripButton, IsoTool> _cgiTools = new Dictionary<ToolStripButton, IsoTool>();
        private List<int> _allItems;
        private List<int> _shownItems = new List<int>();
        private List<MapProblem> _problems = new List<MapProblem>();

        /// <summary>Editable view of the selected statics (property grid on the right).</summary>
        private sealed class CgiSelectionInfo
        {
            [DisplayName("Item-ID (hex)"), Description("Ändert die ID aller ausgewählten Statics.")]
            public string ItemId { get; set; }

            [DisplayName("Hue"), Description("Farbe (0 = original). Gilt für alle ausgewählten Statics.")]
            public int Hue { get; set; }

            [DisplayName("Z"), Description("Höhe. Bei mehreren: alle bekommen diese Höhe.")]
            public int Z { get; set; }

            [DisplayName("X"), Description("Nur bei einem Static änderbar.")]
            public int X { get; set; }

            [DisplayName("Y"), Description("Nur bei einem Static änderbar.")]
            public int Y { get; set; }
        }

        /// <summary>Land tile -> Dragon colour (fallback colours of the CGI view without client files).</summary>
        private void UpdateRuleLandColors()
        {
            var colors = new Dictionary<int, Color>();
            foreach (DragonPaletteEntry e in _rules.Palette.Where(p => p.Defined).OrderBy(p => p.Altitude))
            {
                foreach (ushort id in e.GetTileIds())
                {
                    colors.TryAdd(id, e.Color);
                }
            }
            foreach (TransitionRule r in _rules.Transitions.Where(t => t.Layer == TransitionLayer.Map && t.GroupA >= 0))
            {
                DragonPaletteEntry entry = _rules.EntriesOfGroup(r.GroupA).FirstOrDefault();
                TransitionFile f = _rules.FindTransitionFile(r.File);
                if (entry == null || f == null)
                {
                    continue;
                }
                foreach (TransitionPattern p in f.Patterns)
                {
                    foreach (ushort id in p.GetTileIds())
                    {
                        colors.TryAdd(id, entry.Color);
                    }
                }
            }
            UoArtCache.RuleLandColors = colors;
        }

        private void InitCgi()
        {
            UpdateRuleLandColors();
            _cgiTools[tsbCgiSelect] = IsoTool.Select;
            _cgiTools[tsbCgiPlace] = IsoTool.Place;
            _cgiTools[tsbCgiMulti] = IsoTool.Multi;
            _cgiTools[tsbCgiDelete] = IsoTool.Delete;
            _cgiTools[tsbCgiHue] = IsoTool.Hue;
            _cgiTools[tsbCgiLandSet] = IsoTool.LandSet;
            _cgiTools[tsbCgiRaise] = IsoTool.Raise;
            _cgiTools[tsbCgiLower] = IsoTool.Lower;
            _cgiTools[tsbCgiSetHeight] = IsoTool.SetHeight;
            _cgiTools[tsbCgiSmooth] = IsoTool.Smooth;
            _cgiTools[tsbCgiArea] = IsoTool.Area;
            _cgiTools[tsbCgiCoast] = IsoTool.Coast;
            _cgiTools[tsbCgiWater] = IsoTool.Water;
            isoView.LandPicked += IsoView_LandPicked;
            for (int r = 0; r <= 16; r++)
            {
                tscCgiBrush.Items.Add(r == 0 ? "1 Tile" : $"{r * 2 + 1}×{r * 2 + 1}");
            }
            tscCgiBrush.SelectedIndex = 0;
            foreach (ComboBox c in new[] { cmbCgiItemSize, cmbCgiLandSize })
            {
                c.Items.AddRange(new object[] { "Bilder klein", "Bilder mittel", "Bilder groß" });
                c.SelectedIndex = 1;
            }
            gridCgiItems.ImageOf = id => UoArtCache.Static(id, 0);
            gridCgiItems.NameOf = UoArtCache.ItemName;
            gridCgiLand.ImageOf = LandPicture;
            gridCgiLand.NameOf = id => UoArtCache.LandName(id) + (UoArtCache.Texture(id) != null ? "  (mit Textur)" : string.Empty);
            LoadCoastSettings(CoastSettings.From(CurrentBuildOptions()));
            InitTemplatesAndCaves();
            BuildCgiLayout();
            SelectCgiTool(IsoTool.Select);
            foreach (string z in new[] { "127", "100", "80", "60", "40", "30", "20", "10", "0" })
            {
                tscCgiMaxZ.Items.Add(z);
            }
            tscCgiMaxZ.Text = "127";
            tsbCgiStatics.Checked = true;
            tsbCgiProblems.Checked = true;
            CgiPlaceSettings_Changed(this, EventArgs.Empty);
            UpdateCgiState();
        }

        private void SelectCgiTool(IsoTool tool)
        {
            isoView.Tool = tool;
            foreach (KeyValuePair<ToolStripButton, IsoTool> kv in _cgiTools)
            {
                kv.Key.Checked = kv.Value == tool;
            }
            if (tool == IsoTool.Multi)
            {
                tabCgiSide.SelectedTab = tabCgiMulti;
            }
            else if (tool == IsoTool.Place || tool == IsoTool.Hue)
            {
                tabCgiSide.SelectedTab = tabCgiItems;
            }
            else if (tool == IsoTool.LandSet || tool == IsoTool.Raise || tool == IsoTool.Lower || tool == IsoTool.SetHeight || tool == IsoTool.Smooth)
            {
                tabCgiSide.SelectedTab = tabCgiLand;
                EnsureLandList();
            }
            else if (tool == IsoTool.Coast || tool == IsoTool.Water || tool == IsoTool.CoastSmooth)
            {
                tabCgiSide.SelectedTab = tabCgiCoast;
            }
            else if (tool == IsoTool.Cave || tool == IsoTool.CaveEntrance)
            {
                tabCgiSide.SelectedTab = tabCgiCave;
            }
            else if (tool == IsoTool.CaveStamp)
            {
                tabCgiSide.SelectedTab = tabCgiStamp;
            }
            else if (tool == IsoTool.Mountain)
            {
                tabCgiSide.SelectedTab = tabCgiMountain;
            }
            else if (tool == IsoTool.Template)
            {
                tabCgiSide.SelectedTab = tabCgiTemplates;
                EnsureTemplateLibrary();
            }
            else if (_tabCgiBrushes != null && (tool == IsoTool.Bridge || tool == IsoTool.Cellar || tool == IsoTool.Dungeon || tool == IsoTool.Course || tool == IsoTool.MountainWall))
            {
                tabCgiSide.SelectedTab = _tabCgiBrushes;
                OpenBrushSection(tool == IsoTool.Bridge ? "build.bridge" : tool == IsoTool.Cellar ? "build.cellar" : tool == IsoTool.Dungeon ? "build.dungeon" :
                    tool == IsoTool.MountainWall ? "build.mountainwall" : "build.course");
            }
            else if (_tabCgiBrushes != null && tool >= IsoTool.Scatter)
            {
                tabCgiSide.SelectedTab = _tabCgiBrushes;
            }
            if (_cgiNav.Count > 0)
            {
                UpdateCgiNav();
            }
            // the Z offset belongs to the tool: 'Z +' of the items or of the templates
            isoView.ZOffset = tool == IsoTool.Template ? (int)numCgiTplZ.Value : (int)numCgiZOffset.Value;
            isoView.Invalidate();
            UpdateCgiKeys();
            UpdateCgiOptions();
        }

        private void CgiTool_Click(object sender, EventArgs e)
        {
            if (sender is ToolStripButton b && _cgiTools.TryGetValue(b, out IsoTool tool))
            {
                SelectCgiTool(tool);
                isoView.Focus();
            }
        }

        private void UpdateCgiState()
        {
            bool has = _cgiMap != null;
            tsbCgiSave.Enabled = tsbCgiSaveAs.Enabled = has;
            tsbCgiUndo.Enabled = has && _cgiMap.CanUndo;
            tsbCgiRedo.Enabled = has && _cgiMap.CanRedo;
            btnCgiScan.Enabled = has;
            tabCgi.Text = L.T("CGI-Ansicht") + (has && (_cgiMap.StaticsModified || _cgiMap.LandModified) ? " *" : string.Empty);
            UpdateSyncMarks();
        }

        private void SetCgiMap(MapData data, double? centerX = null, double? centerY = null)
        {
            _cgiMap = data;
            _problems.Clear();
            lstCgiProblems.DataSource = null;
            isoView.SetProblems(null);
            isoView.SetMap(data);
            numCgiX.Maximum = Math.Max(0, data.Width - 1);
            numCgiY.Maximum = Math.Max(0, data.Height - 1);
            if (centerX.HasValue && centerY.HasValue)
            {
                isoView.CenterOn(centerX.Value, centerY.Value);
            }
            UpdateCgiThumbnail();
            UpdateCgiState();
            WatchCgiMap();
            tabMain.SelectedTab = tabCgi;
            isoView.Focus();
        }

        /// <summary>Overview: the editor colours when the map was built from the editor, otherwise radar colours.</summary>
        private void UpdateCgiThumbnail()
        {
            if (_cgiMap == null)
            {
                return;
            }
            Bitmap thumb;
            if (_cgiFromEditor && _map != null && _map.Width == _cgiMap.Width && _map.Height == _cgiMap.Height)
            {
                thumb = IndexedBitmapIO.ToBitmap(_map, _rules.GetColors(), 1024);
            }
            else
            {
                thumb = RadarThumbnail(_cgiMap, 1024);
            }
            cgiNavigator.SetThumbnail(thumb, _cgiMap.Width, _cgiMap.Height);
            cgiNavigator.SetView(isoView.ViewRect);
            UpdateCgiMark();
            // the client files are there now: pictures for the category buttons / sections
            RefreshCgiIcons();
            UpdateStampPreview();
        }

        private void UpdateCgiMark()
        {
            Rectangle sel = mapCanvas.Selection;
            cgiNavigator.SetMark(sel.IsEmpty ? RectangleF.Empty : new RectangleF(sel.X, sel.Y, sel.Width, sel.Height));
        }

        private bool ConfirmDiscardCgi()
        {
            if (RegionBlocks())
            {
                return false;
            }
            if (_cgiMap == null || !_cgiMap.StaticsModified)
            {
                return true;
            }
            DialogResult r = MessageBox.Show(this, "Die Statics in der CGI-Ansicht wurden geändert. Speichern?", Text, MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
            if (r == DialogResult.Cancel)
            {
                return false;
            }
            return r == DialogResult.No || SaveCgi(null);
        }

        // ================================================================== build / load / save

        private void TsbCgiBuild_Click(object sender, EventArgs e) => BuildCgiFromEditor(null, null);

        private void BuildCgiFromEditor(double? cx, double? cy)
        {
            if (_map == null)
            {
                MessageBox.Show(this, "Im Karten-Editor ist keine Karte geöffnet.", Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (!ConfirmDiscardCgi())
            {
                return;
            }
            EnsureCaveRule(_map);
            BuildOptions o = CurrentBuildOptions();
            o.ExtraStatics = _staticsLayer.Items.ToList();
            o.ExtraHeights = _staticsLayer.CropHeights(new Rectangle(0, 0, _map.Width, _map.Height));
            o.ExtraStaticsComplete = _staticsLayer.Complete;
            DragonRuleSet rules = _rules;
            IndexedMap copy = _map.Clone();
            RunBusy("CGI-Karte bauen", (progress, token) => new DragonCompiler(rules, o, Log).BuildInMemory(copy, progress, token), data =>
            {
                _cgiFromEditor = true;
                _cgiUserEdits = false;
                SetCgiMap(data, cx ?? data.Width / 2.0, cy ?? data.Height / 2.0);
                ForgetPending();
                SetStatus($"CGI-Karte gebaut: {data.Width}×{data.Height}, {data.StaticCount:N0} Statics. 'Speichern' schreibt nach {o.OutputFolder}.");
                if (!UoArtCache.ArtAvailable)
                {
                    SetStatus("Hinweis: Keine Client-Grafiken geladen – UoFiddler-Pfad zum Client prüfen. Es werden Radarfarben gezeigt.");
                }
            });
        }

        private void TsbCgiLoad_Click(object sender, EventArgs e)
        {
            if (!ConfirmDiscardCgi())
            {
                return;
            }
            using var dlg = new OpenFileDialog { Filter = "Karten|map*.mul;map*LegacyMUL.uop|Alle Dateien|*.*", Title = "Karte für die CGI-Ansicht laden", InitialDirectory = CurrentBuildOptions().OutputFolder };
            if (dlg.ShowDialog(this) != DialogResult.OK)
            {
                return;
            }
            string file = dlg.FileName;
            int num = MulMapIO.GuessMapNumber(file);
            MapSizePreset size = MulMapIO.GuessSize(file, _map?.Width ?? 0, _map?.Height ?? 0, num);
            if (size == null)
            {
                MessageBox.Show(this, "Die Kartengröße passt zu keiner bekannten Größe. Bitte im Reiter 'MUL / UOP erzeugen' unter 'MUL / UOP → BMP' Breite und Höhe einstellen – diese Werte werden benutzt.",
                    Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            int w = size?.Width ?? (int)numM2BWidth.Value / 8 * 8;
            int h = size?.Height ?? (int)numM2BHeight.Value / 8 * 8;
            RunBusy("Karte laden", (progress, token) =>
            {
                MapData data = MapData.LoadFiles(file, w, h, num, out string info);
                return (data, info);
            }, r =>
            {
                _cgiFromEditor = false;
                SetCgiMap(r.data);
                ForgetPending();
                SetStatus($"Geladen: {file} ({w}×{h}), {r.info}");
            });
        }

        private void TsbCgiSave_Click(object sender, EventArgs e) => SaveCgi(null);

        private void TsbCgiSaveAs_Click(object sender, EventArgs e)
        {
            using var dlg = new FolderBrowserDialog { Description = "Ordner für map / staidx / statics", SelectedPath = _cgiMap?.Folder ?? CurrentBuildOptions().OutputFolder };
            if (dlg.ShowDialog(this) == DialogResult.OK)
            {
                SaveCgi(dlg.SelectedPath);
            }
        }

        /// <summary>
        /// Saves the statics. A map that was built in memory is saved completely (map + statics, UOP when set in the build options).
        /// </summary>
        private bool SaveCgi(string folder)
        {
            if (RegionBlocks())
            {
                return false;
            }
            if (_cgiMap == null)
            {
                return false;
            }
            if (!WarnPending(true, false))
            {
                return false;
            }
            BuildOptions o = CurrentBuildOptions();
            bool builtInMemory = _cgiMap.Folder == null;
            folder ??= _cgiMap.Folder ?? o.OutputFolder;
            bool writeMap = builtInMemory || _cgiMap.LandModified || !File.Exists(Path.Combine(folder, $"map{_cgiMap.MapNumber}.mul"));
            try
            {
                if (builtInMemory)
                {
                    _cgiMap.MapNumber = o.MapNumber;
                }
                List<string> files = _cgiMap.Save(folder, writeMap, o.WriteUop);
                files.ForEach(f => Log("CGI gespeichert: " + f));
                SetStatus($"Gespeichert in {folder}: {string.Join(", ", files.Select(Path.GetFileName))}");
                UpdateCgiState();
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Speichern fehlgeschlagen: " + ex.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        // ================================================================== editor link / navigation

        private void TsbCgiHere_Click(object sender, EventArgs e)
        {
            RectangleF v = mapCanvas.ViewRect;
            double cx = v.X + v.Width / 2, cy = v.Y + v.Height / 2;
            if (_cgiMap == null || _map == null || _cgiMap.Width != _map.Width || _cgiMap.Height != _map.Height || (_cgiFromEditor && _map.Modified && !_cgiMap.StaticsModified))
            {
                BuildCgiFromEditor(cx, cy);
                return;
            }
            tabMain.SelectedTab = tabCgi;
            isoView.CenterOn(cx, cy);
            isoView.Focus();
        }

        private void BtnCgiGoto_Click(object sender, EventArgs e)
        {
            isoView.CenterOn((double)numCgiX.Value, (double)numCgiY.Value);
            isoView.Focus();
        }

        private void BtnCgiToSelection_Click(object sender, EventArgs e)
        {
            Rectangle sel = mapCanvas.Selection;
            if (sel.IsEmpty)
            {
                SetStatus("Im Karten-Editor ist nichts markiert (Werkzeug 'Auswahl').");
                return;
            }
            isoView.CenterOn(sel.X + sel.Width / 2.0, sel.Y + sel.Height / 2.0);
            UpdateCgiMark();
            isoView.Focus();
        }

        private void CgiNavigator_NavigateTo(object sender, MapPointEventArgs e)
        {
            isoView.CenterOn(e.X, e.Y);
        }

        private void IsoView_ViewChanged(object sender, EventArgs e)
        {
            cgiNavigator.SetView(isoView.ViewRect);
            Point c = isoView.CameraTile;
            lblZoom.Text = $"Zoom {isoView.Zoom:0.##}×";
            if (!numCgiX.Focused && !numCgiY.Focused)
            {
                numCgiX.Value = Math.Clamp(c.X, 0, (int)numCgiX.Maximum);
                numCgiY.Value = Math.Clamp(c.Y, 0, (int)numCgiY.Maximum);
            }
        }

        private void IsoView_HoverChanged(object sender, MapPointEventArgs e)
        {
            if (_cgiMap == null || !_cgiMap.InBounds(e.X, e.Y))
            {
                lblPosition.Text = "-";
                return;
            }
            ushort land = _cgiMap.LandId(e.X, e.Y);
            List<StaticItem> statics = _cgiMap.StaticsAt(e.X, e.Y).ToList();
            string st = statics.Count == 0 ? string.Empty : "  |  " + string.Join(", ", statics.Take(4).Select(s => $"{s.Id:x4}@{s.Z}")) + (statics.Count > 4 ? " …" : string.Empty);
            lblPosition.Text = $"X {e.X}  Y {e.Y}  Land {land:x4} {UoArtCache.LandName(land)} z {_cgiMap.LandZ(e.X, e.Y)}{st}";
        }

        private void IsoView_Message(object sender, string e)
        {
            SetStatus(e);
            UpdateCgiKeys();
        }

        /// <summary>Keys and mouse of the current tool, always visible below the view.</summary>
        private void UpdateCgiKeys()
        {
            string text = isoView.KeyHelp();
            if (lblCgiKeys.Text != text)
            {
                lblCgiKeys.Text = text;
            }
        }

        /// <summary>The user changed the CGI map by hand (statics, land) since it was built / refreshed from the colour map.</summary>
        private bool _cgiUserEdits;

        private void IsoView_MapChanged(object sender, EventArgs e)
        {
            _cgiUserEdits = true;
            UpdateCgiState();
        }

        private void TsbCgiUndo_Click(object sender, EventArgs e) => isoView.Undo();

        private void TsbCgiRedo_Click(object sender, EventArgs e) => isoView.Redo();

        private void TsbCgiZoomIn_Click(object sender, EventArgs e) => isoView.ZoomStep(1);

        private void TsbCgiZoomOut_Click(object sender, EventArgs e) => isoView.ZoomStep(-1);

        private void TsbCgiView_Click(object sender, EventArgs e)
        {
            isoView.ShowGrid = tsbCgiGrid.Checked;
            isoView.ShowStatics = tsbCgiStatics.Checked;
            isoView.ShowProblems = tsbCgiProblems.Checked;
            isoView.ShowHeights = tsbCgiHeights.Checked;
            isoView.TranslucentWater = tsbCgiSeeThrough.Checked;
            isoView.TopDown = tsbCgi2D.Checked;
            isoView.Refresh(true);
            UpdateCgiKeys();
        }

        private void TscCgiMaxZ_Changed(object sender, EventArgs e)
        {
            if (int.TryParse(tscCgiMaxZ.Text, NumberStyles.Integer, CultureInfo.InvariantCulture, out int z))
            {
                isoView.MaxZ = Math.Clamp(z, -128, 127);
                isoView.Refresh(true);
            }
        }

        // ================================================================== land / textures

        private List<int> _allLand;
        private List<int> _shownLand = new List<int>();

        private void EnsureLandList()
        {
            if (_allLand != null)
            {
                return;
            }
            bool art = UoArtCache.ArtAvailableCached;
            _allLand = new List<int>();
            for (int id = 0; id <= UoArtCache.MaxLandId; id++)
            {
                if (!art || UoArtCache.IsValidLand(id))
                {
                    _allLand.Add(id);
                }
            }
            if (_allLand.Count == 0)
            {
                // art index not readable: show all ids instead of an empty catalogue
                _allLand.AddRange(Enumerable.Range(0, UoArtCache.MaxLandId + 1));
            }
            ApplyLandFilter();
            CgiLandSettings_Changed(this, EventArgs.Empty);
        }

        private void ApplyLandFilter()
        {
            string f = txtCgiLandFilter.Text.Trim();
            string hexText = f.StartsWith("0x", StringComparison.OrdinalIgnoreCase) ? f.Substring(2) : f;
            bool isHex = HexList.TryParseHex(hexText, out _);
            _shownLand = string.IsNullOrEmpty(f)
                ? _allLand ?? new List<int>()
                : (_allLand ?? new List<int>()).Where(id => (isHex && id.ToString("x4").Contains(hexText, StringComparison.OrdinalIgnoreCase)) ||
                                                            UoArtCache.LandName(id).Contains(f, StringComparison.OrdinalIgnoreCase)).ToList();
            gridCgiLand.Ids = _shownLand;
        }

        private void TxtCgiLandFilter_TextChanged(object sender, EventArgs e) => ApplyLandFilter();

        /// <summary>Picture in the land catalogue: land art, or the texture (for slopes) when 'Texturen zeigen' is on.</summary>
        private Image LandPicture(int id)
        {
            return chkCgiLandTextures.Checked ? UoArtCache.Texture(id) ?? (Image)UoArtCache.Land(id) : UoArtCache.Land(id);
        }

        private void ChkCgiLandTextures_CheckedChanged(object sender, EventArgs e) => gridCgiLand.Invalidate();

        private void GridCgiLand_SelectedIdChanged(object sender, EventArgs e)
        {
            if (gridCgiLand.SelectedId < 0)
            {
                return;
            }
            txtCgiLandId.Text = gridCgiLand.SelectedId.ToString("x4");
            if (isoView.Tool != IsoTool.LandSet)
            {
                SelectCgiTool(IsoTool.LandSet);
            }
        }

        private void GridCgiLand_ItemActivated(object sender, EventArgs e)
        {
            SelectCgiTool(IsoTool.LandSet);
            isoView.Focus();
        }

        private void CmbCgiGridSize_SelectedIndexChanged(object sender, EventArgs e)
        {
            int[] sizes = { 48, 64, 96 };
            if (sender is ComboBox c && c.SelectedIndex >= 0)
            {
                (c == cmbCgiItemSize ? gridCgiItems : gridCgiLand).CellSize = sizes[c.SelectedIndex];
            }
        }

        private void TscCgiBrush_SelectedIndexChanged(object sender, EventArgs e)
        {
            isoView.LandRadius = Math.Max(0, tscCgiBrush.SelectedIndex);
            isoView.Invalidate();
        }

        private void BtnCgiAreaFill_Click(object sender, EventArgs e) => isoView.FillArea();

        private void BtnCgiAreaHeight_Click(object sender, EventArgs e) => isoView.SetAreaHeight();

        private void BtnCgiAreaSmooth_Click(object sender, EventArgs e) => isoView.SmoothArea();

        private void BtnCgiLandCatalog_Click(object sender, EventArgs e) => OpenCatalog(TileCatalogMode.Land);

        private void BtnCgiItemCatalog_Click(object sender, EventArgs e) => OpenCatalog(TileCatalogMode.Items);

        /// <summary>Big picture catalogue (land, textures, items); the chosen tile goes to the matching tool.</summary>
        private void OpenCatalog(TileCatalogMode mode)
        {
            EnsureLandList();
            EnsureItemList();
            int current = mode == TileCatalogMode.Items ? isoView.PlaceId : isoView.PlaceLandId;
            using var dlg = new TilePickerForm(_allLand, _allItems, mode, current);
            if (dlg.ShowDialog(this) != DialogResult.OK || dlg.SelectedId < 0)
            {
                return;
            }
            if (dlg.Mode == TileCatalogMode.Items)
            {
                ShowInItemCatalog(dlg.SelectedId);
                SelectCgiTool(IsoTool.Place);
            }
            else
            {
                txtCgiLandId.Text = dlg.SelectedId.ToString("x4");
                gridCgiLand.SelectedId = dlg.SelectedId;
                chkCgiLandTextures.Checked = dlg.Mode == TileCatalogMode.Textures;
                SelectCgiTool(IsoTool.LandSet);
            }
            isoView.Focus();
        }

        private void CgiLandSettings_Changed(object sender, EventArgs e)
        {
            // one id or a list (e.g. from the colour table): one of them is taken at random per tile
            ushort[] ids = HexList.Parse(txtCgiLandId.Text).Select(i => (ushort)(i & 0x3FFF)).ToArray();
            if (ids.Length > 0)
            {
                isoView.PlaceLandId = ids[0];
            }
            isoView.PlaceLandIds = ids;
            isoView.LandFlatten = chkCgiLandFlatten.Checked;
            isoView.HeightStep = (int)numCgiStep.Value;
            isoView.TargetHeight = (int)numCgiTarget.Value;
            picCgiLandArt.Image = UoArtCache.Land(isoView.PlaceLandId);
            picCgiLandTex.Image = UoArtCache.Texture(isoView.PlaceLandId);
            string wet = UoArtCache.LandIsWetFlat(isoView.PlaceLandId) ? L.T(" · nass, ohne Textur (wird flach gezeichnet)") : string.Empty;
            lblCgiLandInfo.Text = $"{isoView.PlaceLandId:x4} {UoArtCache.LandName(isoView.PlaceLandId)}{wet}{Environment.NewLine}" +
                                  L.T("Links Land-Grafik, rechts Textur für Hänge. Bild anklicken = auswählen, Doppelklick = malen. " +
                                      "Bereich-Knöpfe gelten für den mit 'Bereich' markierten Teil (Höhe = nimmt 'Höhe = :').");
            if (gridCgiLand.SelectedId != isoView.PlaceLandId)
            {
                gridCgiLand.SelectedId = isoView.PlaceLandId;
            }
            isoView.Invalidate();
        }

        private void IsoView_LandPicked(object sender, MapPointEventArgs e)
        {
            txtCgiLandId.Text = e.Index.ToString("x4");
            numCgiTarget.Value = Math.Clamp(_cgiMap.LandZ(e.X, e.Y), -128, 127);
            SetStatus($"Land aufgenommen: {e.Index:x4} {UoArtCache.LandName(e.Index)}, Höhe {_cgiMap.LandZ(e.X, e.Y)}");
        }

        // ================================================================== items / hue / multis

        private void EnsureItemList()
        {
            if (_allItems != null)
            {
                return;
            }
            _allItems = new List<int>();
            bool art = UoArtCache.ArtAvailableCached;
            int max = art ? Math.Min(UoArtCache.MaxItemId, 0x1FFFF) : 0x3FFF;
            for (int id = 0; id <= max; id++)
            {
                if (!art || UoArtCache.IsValidStatic(id))
                {
                    _allItems.Add(id);
                }
            }
            ApplyItemFilter();
        }

        private void ApplyItemFilter()
        {
            string f = txtCgiFilter.Text.Trim();
            if (string.IsNullOrEmpty(f))
            {
                _shownItems = _allItems ?? new List<int>();
            }
            else
            {
                string hexText = f.StartsWith("0x", StringComparison.OrdinalIgnoreCase) ? f.Substring(2) : f;
                bool isHex = HexList.TryParseHex(hexText, out _);
                _shownItems = (_allItems ?? new List<int>()).Where(id =>
                    (isHex && id.ToString("x4").Contains(hexText, StringComparison.OrdinalIgnoreCase)) ||
                    UoArtCache.ItemName(id).Contains(f, StringComparison.OrdinalIgnoreCase)).ToList();
            }
            gridCgiItems.Ids = _shownItems;
        }

        private void TxtCgiFilter_TextChanged(object sender, EventArgs e) => ApplyItemFilter();

        private void GridCgiItems_SelectedIdChanged(object sender, EventArgs e)
        {
            if (gridCgiItems.SelectedId < 0)
            {
                return;
            }
            txtCgiItemId.Text = gridCgiItems.SelectedId.ToString("x4");
            if (isoView.Tool != IsoTool.Place && isoView.Tool != IsoTool.Hue)
            {
                SelectCgiTool(IsoTool.Place);
            }
        }

        private void GridCgiItems_ItemActivated(object sender, EventArgs e)
        {
            SelectCgiTool(IsoTool.Place);
            isoView.Focus();
        }

        /// <summary>Shows an item in the catalogue (clears a filter that hides it) and takes it as the item to place.</summary>
        private void ShowInItemCatalog(int id)
        {
            EnsureItemList();
            if (!gridCgiItems.Contains(id) && txtCgiFilter.Text.Length > 0)
            {
                txtCgiFilter.Text = string.Empty;
            }
            gridCgiItems.SelectedId = id;
            txtCgiItemId.Text = id.ToString("x4");
            tabCgiSide.SelectedTab = tabCgiItems;
        }

        private void CgiPlaceSettings_Changed(object sender, EventArgs e)
        {
            if (HexList.TryParseHex(txtCgiItemId.Text, out ushort id))
            {
                isoView.PlaceId = id;
                if (gridCgiItems.SelectedId != id)
                {
                    gridCgiItems.SelectedId = id;
                }
            }
            isoView.PlaceHue = (ushort)numCgiHue.Value;
            if (isoView.Tool != IsoTool.Template)
            {
                isoView.ZOffset = (int)numCgiZOffset.Value;
            }
            isoView.StackOnStatics = chkCgiStack.Checked;
            isoView.MultiInvisibleParts = chkCgiMultiInvisible.Checked;
            Color hueColor = UoArtCache.HueColor(isoView.PlaceHue);
            panelCgiHueSwatch.BackColor = hueColor == Color.Transparent ? SystemColors.Control : hueColor;
            picCgiItem.Image = UoArtCache.Static(isoView.PlaceId, isoView.PlaceHue);
            lblCgiItemInfo.Text = $"{isoView.PlaceId:x4} {UoArtCache.ItemName(isoView.PlaceId)}  ·  Höhe {UoArtCache.ItemHeight(isoView.PlaceId)}  ·  Hue {isoView.PlaceHue}: {UoArtCache.HueName(isoView.PlaceHue)}" +
                                  $"{Environment.NewLine}TileData: {UoArtCache.ItemFlagsText(isoView.PlaceId)}";
            isoView.Invalidate();
        }

        private void NumCgiMultiId_ValueChanged(object sender, EventArgs e)
        {
            isoView.MultiId = (int)numCgiMultiId.Value;
            picCgiMulti.Image?.Dispose();
            picCgiMulti.Image = UoArtCache.MultiImage(isoView.MultiId);
            lblCgiMultiInfo.Text = isoView.MultiPartCount > 0
                ? $"Multi {isoView.MultiId:x4}: {isoView.MultiPartCount} Teile. Werkzeug 'Multi setzen' und in die Karte klicken."
                : $"Multi {isoView.MultiId:x4}: nicht vorhanden (oder Client-Dateien nicht geladen).";
            if (isoView.Tool != IsoTool.Multi && isoView.MultiPartCount > 0 && tabCgiSide.SelectedTab == tabCgiMulti)
            {
                SelectCgiTool(IsoTool.Multi);
            }
        }

        /// <summary>Right click on a static: take over id and hue.</summary>
        private void IsoView_ItemPicked(object sender, StaticPickEventArgs e)
        {
            ShowInItemCatalog(e.Item.Id);
            numCgiHue.Value = Math.Clamp(e.Item.Hue, 0, (int)numCgiHue.Maximum);
            SetStatus($"Aufgenommen: {e.Item.Id:x4} {UoArtCache.ItemName(e.Item.Id)}, Hue {e.Item.Hue}");
        }

        // ================================================================== selection panel

        private void IsoView_SelectionChanged(object sender, EventArgs e)
        {
            IReadOnlyCollection<StaticItem> sel = isoView.Selection;
            if (sel.Count == 0)
            {
                lblCgiSelInfo.Text = L.T("Nichts ausgewählt.") + Environment.NewLine +
                                     L.T("Klick = auswählen, Strg+Klick = dazu, Umschalt+Klick = alles auf dem Tile.");
                propCgiSelection.SelectedObject = null;
                UpdateCgiState();
                return;
            }
            StaticItem f = sel.First();
            if (sel.All(s => s.Id == f.Id) && gridCgiItems.Contains(f.Id))
            {
                // the selected item is also marked in the catalogue (ready to place again)
                gridCgiItems.SelectedId = f.Id;
            }
            UpdateCgiKeys();
            lblCgiSelInfo.Text = sel.Count == 1
                ? $"{f.Id:x4} {UoArtCache.ItemName(f.Id)}{Environment.NewLine}({f.X}, {f.Y}, {f.Z})  Hue {f.Hue}  ·  TileData: {UoArtCache.ItemFlagsText(f.Id)}{Environment.NewLine}" +
                  L.T("Pfeile = verschieben, Strg+Pfeil = Kopie daneben, Bild↑/↓ = Z, Entf = löschen")
                : $"{sel.Count} " + L.T("Statics ausgewählt.") + Environment.NewLine + L.T("Pfeile = verschieben, Strg+Pfeil = Kopie daneben, Bild↑/↓ = Z, Entf = löschen");
            propCgiSelection.SelectedObject = new CgiSelectionInfo { ItemId = f.Id.ToString("x4"), Hue = f.Hue, Z = f.Z, X = f.X, Y = f.Y };
            UpdateCgiState();
        }

        private void BtnCgiSelToCatalog_Click(object sender, EventArgs e)
        {
            StaticItem f = isoView.Selection.FirstOrDefault();
            if (f == null)
            {
                SetStatus("Nichts ausgewählt.");
                return;
            }
            IsoView_ItemPicked(this, new StaticPickEventArgs(f));
        }

        private void BtnCgiSelCopy_Click(object sender, EventArgs e)
        {
            isoView.CopySelection();
            isoView.Focus();
        }

        private void BtnCgiSelPaste_Click(object sender, EventArgs e)
        {
            isoView.BeginPaste();
            isoView.Focus();
        }

        // ================================================================== coast / water

        private bool _loadingCoast;

        private void LoadCoastSettings(CoastSettings c)
        {
            _loadingCoast = true;
            txtCgiCoastHeights.Text = c.LandHeights;
            numCgiCoastMaxLand.Value = Math.Clamp(c.MaxLandZ, -128, 127);
            numCgiFloorZ.Value = Math.Clamp(c.FloorZ, -128, 127);
            numCgiWaterWidth.Value = Math.Clamp(c.WaterWidth, 0, 16);
            numCgiSurfaceZ.Value = Math.Clamp(c.SurfaceZ, -128, 127);
            txtCgiFloorTiles.Text = c.FloorTiles;
            txtCgiWaterIds.Text = c.WaterStaticIds;
            _loadingCoast = false;
            CgiCoastSettings_Changed(this, EventArgs.Empty);
        }

        private void CgiCoastSettings_Changed(object sender, EventArgs e)
        {
            if (_loadingCoast)
            {
                return;
            }
            isoView.Coast = new CoastSettings
            {
                LandHeights = txtCgiCoastHeights.Text,
                MaxLandZ = (int)numCgiCoastMaxLand.Value,
                FloorZ = (int)numCgiFloorZ.Value,
                WaterWidth = (int)numCgiWaterWidth.Value,
                SurfaceZ = (int)numCgiSurfaceZ.Value,
                FloorTiles = txtCgiFloorTiles.Text,
                WaterStaticIds = txtCgiWaterIds.Text,
                SetFloor = chkCgiSetFloor.Checked
            };
            ushort[] ids = HexList.Parse(txtCgiWaterIds.Text);
            string water = ids.Length == 0
                ? L.T("keine gültige ID")
                : string.Join(Environment.NewLine, ids.Distinct().Take(4).Select(id =>
                    $"{id:x4} {UoArtCache.ItemName(id)}: {(UoArtCache.IsTranslucent(id) ? L.T("durchsichtig") : L.T("deckend"))} ({UoArtCache.ItemFlagsText(id)})"));
            lblCgiCoastInfo.Text =
                L.T("Pinsel 'Küste' / Taste K: Wasser bis 'Breite' vom Land = Grund-Tile auf 'Meeresgrund z' (äußerer Ring = 'Wasser z') " +
                    "mit Wasser-Statics auf 'Wasser z'; Land am Wasser bekommt die Strand-Höhen (1., 2., 3. Tile). Land höher als 'Klippe ab z' bleibt.") +
                Environment.NewLine + Environment.NewLine +
                L.T("Pinsel 'Wasser': setzt die Wasser-Statics (zufällig aus der Liste), Strg = entfernen. Durchsichtig zeichnet der Client nur Items mit dem TileData-Flag 'Translucent':") +
                Environment.NewLine + water;
        }

        private void BtnCgiCoastDefaults_Click(object sender, EventArgs e) => LoadCoastSettings(CoastSettings.From(CurrentBuildOptions()));

        private void BtnCgiWaterFromItem_Click(object sender, EventArgs e) => txtCgiWaterIds.Text = isoView.PlaceId.ToString("x4");

        private void BtnCgiCoastArea_Click(object sender, EventArgs e) => isoView.ShapeCoastArea();

        private void BtnCgiWaterArea_Click(object sender, EventArgs e) => isoView.WaterArea(false);

        private void BtnCgiWaterAreaRemove_Click(object sender, EventArgs e) => isoView.WaterArea(true);

        private void PropCgiSelection_PropertyValueChanged(object s, PropertyValueChangedEventArgs e)
        {
            if (propCgiSelection.SelectedObject is not CgiSelectionInfo info)
            {
                return;
            }
            switch (e.ChangedItem?.PropertyDescriptor?.Name)
            {
                case nameof(CgiSelectionInfo.ItemId):
                    if (HexList.TryParseHex(info.ItemId, out ushort id))
                    {
                        isoView.ModifySelection(t => t.Id = id, $"ID → {id:x4}");
                    }
                    break;
                case nameof(CgiSelectionInfo.Hue):
                    isoView.ModifySelection(t => t.Hue = (ushort)Math.Clamp(info.Hue, 0, 0xFFFF), $"Hue → {info.Hue}");
                    break;
                case nameof(CgiSelectionInfo.Z):
                    isoView.ModifySelection(t => t.Z = Math.Clamp(info.Z, -128, 127), $"Z → {info.Z}");
                    break;
                case nameof(CgiSelectionInfo.X):
                case nameof(CgiSelectionInfo.Y):
                    if (isoView.Selection.Count == 1 && _cgiMap.InBounds(info.X, info.Y))
                    {
                        isoView.ModifySelection(t =>
                        {
                            t.X = info.X;
                            t.Y = info.Y;
                        }, $"Position → ({info.X}, {info.Y})");
                    }
                    else
                    {
                        IsoView_SelectionChanged(this, EventArgs.Empty);
                    }
                    break;
            }
            isoView.Focus();
        }

        // ================================================================== problems

        private void BtnCgiScan_Click(object sender, EventArgs e)
        {
            if (_cgiMap == null)
            {
                return;
            }
            MapData data = _cgiMap;
            var o = new ProblemScanOptions { CliffHeight = (int)numCgiCliff.Value };
            RunBusy("Karte prüfen", (progress, token) => MapProblemScanner.Scan(data, o, progress, token), list =>
            {
                _problems = list;
                _fillingProblems = true;
                lstCgiProblems.DataSource = null;
                lstCgiProblems.DataSource = list;
                lstCgiProblems.ClearSelected();
                _fillingProblems = false;
                isoView.SetProblems(list);
                tabCgiSide.SelectedTab = tabCgiProblems;
                string summary = string.Join(", ", list.GroupBy(p => p.Kind).Select(g => $"{KindName(g.Key)}: {g.Count()}"));
                SetStatus(list.Count == 0 ? "Keine Probleme gefunden." : $"{list.Count} Probleme{(list.Count >= o.MaxResults ? " (Liste gekürzt)" : string.Empty)} – {summary}");
            });
        }

        private static string KindName(MapProblemKind k)
        {
            switch (k)
            {
                case MapProblemKind.MissingLandArt: return "Land ohne Grafik";
                case MapProblemKind.MissingStaticArt: return "Static ohne Grafik";
                case MapProblemKind.Cliff: return "Steilkanten";
                case MapProblemKind.StaticBelowGround: return "im Boden";
                case MapProblemKind.Coast: return "Küste";
                default: return "doppelt";
            }
        }

        private bool _fillingProblems;

        private void LstCgiProblems_DoubleClick(object sender, EventArgs e)
        {
            if (!_fillingProblems && lstCgiProblems.SelectedItem is MapProblem p)
            {
                isoView.CenterOn(p.X, p.Y);
            }
        }
    }
}
